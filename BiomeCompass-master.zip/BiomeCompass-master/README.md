# BiomeCompass

This mod adds the ability to locate biomes.

It uses Forge 1.7.10

Reference: 
* http://cmicro.github.io/NeatCraft/forge-javadoc/
* http://www.wuppy29.com/minecraft/modding-tutorials/forge-modding-1-7/

Credits:
* Item textures: @Xander_Fury
* French translation: @Mazdallier

