package org.bukkit.entity;

/**
 * Represents an ambient mob
 */
public interface Ambient extends LivingEntity {}
