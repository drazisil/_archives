package org.bukkit.entity;

/**
 * Represents a falling block.
 *
 * @deprecated See {@link FallingBlock}
 */
@Deprecated
public interface FallingSand extends FallingBlock {}
