package org.bukkit.entity;

/**
 * Represents a Giant.
 */
public interface Giant extends Monster {}
