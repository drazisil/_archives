package org.bukkit.entity;

/**
 * Represents an Animal.
 */
public interface Animals extends Ageable {}
