package org.bukkit.entity;

/**
 * Represents an Ender Signal, which is often created upon throwing an ender
 * eye
 */
public interface EnderSignal extends Entity {

}
