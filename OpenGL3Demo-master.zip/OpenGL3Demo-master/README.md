# OpenGL3Demo
Expanding on http://www.lwjgl.org/guide

Teaching myself Modern (3.0) OpenGL using LWJGL 3

##References:
* http://www.glprogramming.com/red/appendixf.html
* https://www.khronos.org/files/opengl-quick-reference-card.pdf
* https://en.wikipedia.org/wiki/Translation_(geometry)
