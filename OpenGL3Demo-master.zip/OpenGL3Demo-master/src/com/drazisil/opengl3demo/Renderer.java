/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.opengl3demo;

import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;

import static org.lwjgl.glfw.GLFW.glfwGetTime;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static utility.ShaderLoader.loadShaderPair;

public class Renderer {

    protected float[] vertexDataFloat;
    protected float[] vertexColorsFloat;
    protected FloatBuffer vertexData;
    protected FloatBuffer vertexColors;

    public float xOffset = 0;
    public float yOffset = 0;

    private int shader;
    private float rotation = 0f;
    private float loopDuration;
    private float scale;

    public void init(){
        /**
         * This is a combined float[]
         * The first half contains the position
         * The second half contains the colors
         */
        // Positions
        vertexDataFloat = new float[]{
                0.0f, 0.5f, 0.0f, 1.0f,
                0.5f, -0.366f, 0.0f, 1.0f,
                -0.5f, -0.366f, 0.0f, 1.0f,
        };

        // Colors
        vertexColorsFloat = new float[]{
                1.0f, 0.0f, 0.0f, 1.0f,
                0.0f, 1.0f, 0.0f, 1.0f,
                0.0f, 0.0f, 1.0f, 1.0f,
        };


        // 3 vertices for the triangle
        int amountOfVertices = 3;
        int vertexSize = vertexDataFloat.length;

        /**
         * These next three lines are tricky.
         * They are unique to LWJGL and are referenced in only a few places
         * They are explained in https://github.com/LWJGL/lwjgl3-wiki/wiki/2.6.5-Basics-of-modern-OpenGL-%28Part-II%29#rendering-with-buffers
         */
        // prep the positions
        vertexData = BufferUtils.createFloatBuffer(vertexSize + amountOfVertices);
        vertexData.put(vertexDataFloat);
        vertexData.flip();

        // prep the colors
        vertexColors = BufferUtils.createFloatBuffer(vertexSize + amountOfVertices);
        vertexColors.put(vertexColorsFloat);
        vertexColors.flip();


    }

    public void computeRotation(float delta, String direction){
        //float elapsedTime = (float) (glfwGetTime()); // 1000.0f);

        //float fCurrTimeThroughLoop = elapsedTime % loopDuration;

        float offsetValue = 0.005f;

        if (direction.equals("CW")){
            rotation += offsetValue * delta;
        }
        if (direction.equals("CCW")){
            rotation -= offsetValue * delta;
        }


    }


    /**
     *
     * @param direction left or right
     */
    public void computeXYOffset(float delta, String direction){

        loopDuration = 5.0f;
        scale = 3.14159f * 2.0f / loopDuration;

        float elapsedTime = (float) (glfwGetTime()); // 1000.0f);

        float fCurrTimeThroughLoop = elapsedTime % loopDuration;

        float offsetValue = 0.005f;

        if (direction.equals("Left")){
            xOffset -= offsetValue * delta;
        }
        if (direction.equals("Right")){
            xOffset += offsetValue * delta;
        }
        if (direction.equals("Up")){
            yOffset += offsetValue * delta;
        }
        if (direction.equals("Down")){
            yOffset -= offsetValue * delta;
        }
        if (direction.equals("Reset")){
            xOffset = 0f;
            yOffset = 0f;
            rotation = 0f;

        }

    }

    public void setupShaders() {
        // TODO: Make own shader loader
        shader = loadShaderPair("resources/shaders/triangle.vert", "resources/shaders/triangle.frag");


    }


    public void render() {
        // tell OpenGL what shader id we are using
        glUseProgram(shader);
        int glslPosOffset = glGetUniformLocation(shader, "posOffset");
        glUniform3f(glslPosOffset, xOffset, yOffset, 0.0f);

        int glslAngle = glGetUniformLocation(shader, "angle");
        glUniform1f(glslAngle, rotation);

        // clear the screen
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // attach vertexData to positionBufferObject
        int positionBufferObject = glGenBuffers();
        glBindBuffer(GL_ARRAY_BUFFER, positionBufferObject);
        glBufferData(GL_ARRAY_BUFFER, vertexData, GL_STREAM_DRAW);

        // attach vertexColors to colorBufferObject
        int colorBufferObject = glGenBuffers();
        glBindBuffer(GL_ARRAY_BUFFER, colorBufferObject);
        glBufferData(GL_ARRAY_BUFFER, vertexColors, GL_STATIC_DRAW);

        // Assign positionBufferObject to Attribute 0
        glBindBuffer(GL_ARRAY_BUFFER, positionBufferObject);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 4, GL_FLOAT, false, 0, 0);

        // Assign colorBufferObject to Attribute 1
        glBindBuffer(GL_ARRAY_BUFFER, colorBufferObject);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 4, GL_FLOAT, false, 0, 0);


        // actually draw the triangle
        glDrawArrays(GL_TRIANGLES, 0, 3);

        // disable the attribute array
        glDisableVertexAttribArray(0);
    }


}
