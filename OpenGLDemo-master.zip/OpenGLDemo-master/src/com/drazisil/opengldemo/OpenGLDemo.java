package com.drazisil.opengldemo;

import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;

import static org.lwjgl.opengl.GL11.*;

public class OpenGLDemo {

    private static Renderer renderer;

    private int WIDTH = 1152;
    private int HEIGHT = 720;
    private float defaultScale;
    private float scale;

    public boolean isRunning() {
        return isRunning;
    }

    public void setRunning(boolean isRunning) {
        this.isRunning = isRunning;
    }

    private boolean isRunning = false;

    /** position of quad */
    private float x;
    private float y;
    private float z;
    /** angle of quad rotation */
    private float rotation;


    /** time at last frame */
    long lastFrame;
    /** frames per second */
    int fps;
    /** last fps time */
    long lastFPS;
    private int delta;

    public void start() {

        try {
            Display.setDisplayMode(new DisplayMode(WIDTH,HEIGHT));
            Display.create();
        } catch (LWJGLException e) {
            e.printStackTrace();
            System.exit(0);
        }

        initGL();

        isRunning = true;
        delta = getDelta();
        lastFPS = getTime(); //set lastFPS to current Time

        // Initial values
        x = 400f;
        y = 300f;
        z = 0;
        rotation = 0f;
        defaultScale = 50f;
        scale = defaultScale;

        while (isRunning()) {
            if (Display.isCloseRequested()) {
                isRunning = false;
            }

            delta = getDelta();

            update();
            renderer.renderGL(x, y, z, rotation, scale);

            Display.update();
            Display.sync(60); // cap fps to 60fps
        }

        Display.destroy();
    }

    private void initGL() {
        // init OpenGL
        glMatrixMode(GL11.GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, WIDTH, 0, HEIGHT, 1, -1);
        glMatrixMode(GL11.GL_MODELVIEW);
    }

    public void update() {
        // rotate quad
        //rotation += 0.15f * delta;

        pollInput();

        // keep quad on the screen
        if (x < 0) x = 0;
        if (x > 800) x = 800;
        if (y < 0) y = 0;
        if (y > 600) y = 600;

        updateFPS(); // update FPS Counter
    }

    /**
     * Calculate the FPS and set it in the title bar
     */
    public void updateFPS() {
        if (getTime() - lastFPS > 1000) {
            String TITLE = "Xandangles 1.0";
            Display.setTitle(TITLE + "| FPS: " + fps);
            fps = 0;
            lastFPS += 1000;
        }
        fps++;
    }



    /**
     * Get the time in milliseconds
     *
     * @return The system time in milliseconds
     */
    public long getTime() {
        return (Sys.getTime() * 1000) / Sys.getTimerResolution();
    }

    public int getDelta() {
        long time = getTime();
        int delta = (int) (time - lastFrame);
        lastFrame = time;

        return delta;
    }

    public void pollInput() {

        if (Mouse.isButtonDown(0)) {
            int x = Mouse.getX();
            int y = Mouse.getY();

            System.out.println("MOUSE DOWN @ X: " + x + " Y: " + y);
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
            System.out.println("SPACE KEY IS DOWN");
        }

        // ESCAPE quits
        if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
            setRunning(false);
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_A)) x -= 0.35f * delta;
        if (Keyboard.isKeyDown(Keyboard.KEY_D)) x += 0.35f * delta;
        if (Keyboard.isKeyDown(Keyboard.KEY_W)) y -= 0.35f * delta;
        if (Keyboard.isKeyDown(Keyboard.KEY_S)) y += 0.35f * delta;


        if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) rotation += 0.35f * delta;
        if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) rotation -= 0.35f * delta;

        if (Keyboard.isKeyDown(Keyboard.KEY_Z)) scale += 0.35f * delta;
        if (Keyboard.isKeyDown(Keyboard.KEY_X)) scale -= 0.35f * delta;


        if (Keyboard.isKeyDown(Keyboard.KEY_0) || Keyboard.isKeyDown(Keyboard.KEY_NUMPAD0)) {
            rotation = 0f;
            scale = defaultScale;
        }

    }

    public static void main(String[] argv) {
        //System.setProperty("org.lwjgl.librarypath", new File("natives").getAbsolutePath());
        OpenGLDemo openGLDemo = new OpenGLDemo();
        renderer = new Renderer();
        openGLDemo.start();
    }
}