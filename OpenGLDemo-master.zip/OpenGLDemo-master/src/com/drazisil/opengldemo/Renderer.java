package com.drazisil.opengldemo;

import org.lwjgl.opengl.GL11;

import static org.lwjgl.opengl.GL11.*;

public class Renderer {

    public void renderGL(float x, float y, float z, float rotation, float scale) {
        // Clear The Screen And The Depth Buffer
        glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);

        // draw quad
        glPushMatrix();

        glTranslatef(x, y, 0);
        glRotatef(rotation, 0f, 0f, 1f);
        glTranslatef(-x, -y, 0);

        // R,G,B,A Set The Color To Blue One Time Only
        //glColor3f(0f, 1f, 0f);
        //glBegin(GL11.GL_QUADS);
        //glVertex3f(x - 50, y + 50, 0);
        //glVertex3f(x + 50, y + 50, 0);
        //glVertex3f(x + 50, y - 50, 0);
        //glVertex3f(x - 50, y - 50, 0);
        //glEnd();

        RgbColor colorBlue = new RgbColor(0f, 0f, 1.0f);
        createTriangleEq(colorBlue, x, y, z, scale);

        glTranslatef(x, y, 0);
        glRotatef(rotation + 10, 0f, 0f, 1f);
        glTranslatef(-x, -y, 0);

        RgbColor colorGreen = new RgbColor(0f, 1f, 0f);
        createTriangleEq(colorGreen, x, y, z, scale - 20);

        glTranslatef(x, y, 0);
        glRotatef(rotation + 20, 0f, 0f, 1f);
        glTranslatef(-x, -y, 0);


        RgbColor colorpuke = new RgbColor(2f, 1f, 3f);
        createTriangleEq(colorpuke, x, y, z, scale - 40);

        glPopMatrix();
    }

    public void createTriangleEq(RgbColor color ,float x, float y, float z, float scale){

        float minusY = scale / 2;
        float sideX = minusY * 1.72f;

        // Triangle
        // R,G,B,A Set The Color To Blue One Time Only
        glColor3f(color.red, color.green, color.blue);
        glBegin(GL11.GL_TRIANGLES);
        glVertex3f(x, y + scale, z);
        glVertex3f(x + sideX, y - minusY, z);
        glVertex3f(x - sideX, y - minusY, z);
        glEnd();

        // Center
        glPointSize(5.0f);
        glColor3f(1.0f, 0.0f, 0.0f);
        glBegin(GL11.GL_POINTS);
        glVertex3f(x, y, 0);
        glEnd();

    }
}
