package com.drazisil.opengldemo;

public class RgbColor {

    public float red;
    public float green;
    public float blue;

    public RgbColor(float red, float green, float blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }
}
