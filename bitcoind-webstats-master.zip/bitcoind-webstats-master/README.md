# bitcoind-webstats

Web display frontend for bitcoin nodes

Supported calls:
* _getblockchaininfo_
* _getnetworkinfo_
