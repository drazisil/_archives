from StringIO import StringIO
import base64

from twisted.internet import reactor, task
from twisted.internet.defer import Deferred
from twisted.web.client import Agent, FileBodyProducer
from twisted.web.http_headers import Headers
from modules.util.responsebodyhandler import ResponseBodyHandler


class BitcoinJasonRpc:

    def __init__(self, data_handler, config):
        self._bitcoind_url = config.host
        bitcoind_auth = base64.encodestring('%s:%s' % (config.username, config.password))[:-1]
        self._data_handler = data_handler
        self._headers = Headers({
            "Authorization": ["Basic " + bitcoind_auth],
            "Content-Type": ['application/json'],
            "Accept": ['application/json'],
        })
        self.method = ''

    def call_method(self, method):
        m = method
        if m == "getnetworkinfo":
            self._build_agent('{"method" : "getnetworkinfo", "params" : [], "id": 1}') \
                .addCallback(self._cb_response, m) \
                .addErrback(self._cb_error)
        elif m == 'getblockchaininfo':
            self._build_agent('{"method" : "getblockchaininfo", "params" : [], "id": 1}') \
                .addCallback(self._cb_response, m)\
                .addErrback(self._cb_error)
        elif m == 'getblockcount':
            self._build_agent('{"method" : "getblockcount", "params" : [], "id": 1}') \
                .addCallback(self._cb_response, m)\
                .addErrback(self._cb_error)
        elif m == '_getlatestblockhash':
            self._build_agent('{"method" : "getblockcount", "params" : [], "id": 1}') \
                .addCallback(self._cb_response, "_getlatestblockhash_getblockcount")\
                .addErrback(self._cb_error)
            self._build_agent('{"method" : "getblockhash", "params" : ['+ str(self._data_handler.block_height) +'], "id": 1}') \
                .addCallback(self._cb_response, "_getlatestblockhash")\
                .addErrback(self._cb_error)
        elif m == '_getlatestblockcoinbase':
            self._build_agent('{"method" : "getblockcount", "params" : [], "id": 1}') \
                .addCallback(self._cb_response, "_getlatestblockhash_getblockcount")\
                .addErrback(self._cb_error)
            if self._data_handler.latest_block_height > 0:
                self._build_agent('{"method" : "getblockhash", "params" : ['+ str(self._data_handler.latest_block_height) +'], "id": 1}') \
                    .addCallback(self._cb_response, "_getlatestblockcoinbase_gethash")\
                    .addErrback(self._cb_error)
                if  self._data_handler.latest_block_hash != '':
                    self._build_agent('{"method" : "getblock", "params" : ["'+ str(self._data_handler.latest_block_hash) +'"], "id": 1}') \
                        .addCallback(self._cb_response, "_getlatestblockcoinbase_getblock")\
                        .addErrback(self._cb_error)
                    if self._data_handler.latest_block_coinbase_tx != '':
                        self._build_agent('{"method" : "getrawtransaction", "params" : ["'+ str(self._data_handler.latest_block_coinbase_tx) +'", 1], "id": 1}') \
                            .addCallback(self._cb_response, "_getlatestblockcoinbase")\
                            .addErrback(self._cb_error)
        else:
            print('Not a supported method: ' + m)
            # reactor.callWhenRunning(reactor.stop)

    def _cb_response(self, response, method):
        finished = Deferred()
        response.deliverBody(ResponseBodyHandler(finished, method, self._data_handler))
        return finished

    @staticmethod
    def _cb_error(failure):
        print 'Error received: ', failure.code, " ", failure.phrase, failure.headers, failure.body

    def get_connection_count(self):
        self.call_method('getnetworkinfo')

    def update_data(self, interval):
        task.LoopingCall(self.call_method, '_getlatestblockcoinbase')\
            .start(interval)
        # task.LoopingCall(self.call_method, 'getnetworkinfo')\
        #   .start(interval)
        # task.LoopingCall(self.call_method, 'getblockchaininfo')\
        #   .start(interval)

    def _build_agent(self, request):
        d = Agent(reactor)\
            .request('POST', self._bitcoind_url, self._headers,
                     FileBodyProducer(StringIO(request)))
        return d
