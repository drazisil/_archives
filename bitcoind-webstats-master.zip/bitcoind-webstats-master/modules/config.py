import ConfigParser
import argparse
from modules.util.fakesechead import FakeSecHead

__author__ = 'drazisil'

class Config:

    def __init__(self):
        parser = argparse.ArgumentParser()
        parser.add_argument('-c', '--conf', metavar='path', dest='path', required=True, help='specify a configuration file')
        args = parser.parse_args()

        config = ConfigParser.SafeConfigParser()
        config.readfp(FakeSecHead(open(args.path)))

        self.host = 'http://127.0.0.1:8332'
        self.username = config.get('asection', 'rpcuser')
        self.password = config.get('asection', 'rpcpassword')


