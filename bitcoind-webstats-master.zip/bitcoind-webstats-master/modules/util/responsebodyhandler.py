import binascii
import json
from twisted.internet.protocol import Protocol

__author__ = 'drazisil'

class ResponseBodyHandler(Protocol):
    def __init__(self, finished, method, bodycontent):
        self.finished = finished
        self.remaining = 1024 * 100000
        self.content = ''
        self.method = method
        self._data = bodycontent

    def dataReceived(self, bytes):
        if self.remaining:
            display = bytes[:self.remaining]
            self.content = self.content + display
            # print display
            self.remaining -= len(display)

    def connectionLost(self, reason):

        # TODO: Make sure no errors

        """

        @type reason: L{twisted.python.failure.Failure}
        """
        
        data = json.loads(self.content)

        self.parse_section(data)

        self.finished.callback(None)
        return self.content

    def _handle_key_error(self):
        m = self.method
        self._data.response = 'Error with call: ' + m
        print('Error with call: ' + m)
        print self.content
        

    def parse_section(self, data):
        m = self.method
        # print self.method
        if m == 'getnetworkinfo':
            try:
                self._data.connection_count = data['result']['connections']
                self._data.response = data['result']
            except KeyError:
                _handle_key_error()
        elif m == 'getblockchaininfo':
            try:
                self._data.difficulty = data['result']['difficulty']
                self._data.percent_verified = data['result']['verificationprogress']
                self._data.response = data['result']
            except KeyError:
                _handle_key_error()
        elif m == 'getblockcount':
            try:
                self._data.block_height = data['result']
                self._data.response = data['result']
            except KeyError:
                _handle_key_error()
        elif m == '_getlatestblockhash_getblockcount':
            try:
                self._data.latest_block_height = data['result']
            except KeyError:
                _handle_key_error()
        elif m == '_getlatestblockhash':
            try:
                self._data.latest_block_hash = data['result']
                self._data.response = data['result']
            except KeyError:
                _handle_key_error()
        elif m == '_getlatestblockcoinbase_gethash':
            try:
                self._data.latest_block_hash = data['result']
            except KeyError:
                _handle_key_error()
        elif m == '_getlatestblockcoinbase_getblock':
            try:
                # print(data)
                self._data.latest_block_coinbase_tx = data['result']['tx'][0]
            except KeyError:
                _handle_key_error()
        elif m == '_getlatestblockcoinbase':
            try:
                # print(self._data.latest_block_coinbase_tx)
                # print(data)
                self._data.latest_coinbase = data['result']['vin'][0]['coinbase']
                self._data.response = binascii.unhexlify(self._data.latest_coinbase)
                print(self._data.response)
            except KeyError:
                _handle_key_error()
        else:
            try:
                self._data.response = data['result']
                print data['result']
            except KeyError:
                _handle_key_error()
