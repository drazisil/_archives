__author__ = 'drazisil'

class WebData:

    response = ''
    connection_count = 0
    percent_verified = 0
    difficulty = 0
    latest_block_height = 0
    latest_block_hash = ''
    latest_block_coinbase_tx = ''

    def __init__(self):
        pass

    def get_response(self):
        if type(self.response) == 'String':
            return self.response
        else:
            return str(self.response)
