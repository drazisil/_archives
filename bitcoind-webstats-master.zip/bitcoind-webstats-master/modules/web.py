from twisted.internet import reactor
from twisted.web import server
from twisted.web.resource import Resource

__author__ = 'drazisil'


class RcRoot(Resource):
    def __init__(self, data_handler):
        Resource.__init__(self)
        self._data = data_handler

    # this code lets you call the resource as itself, as well as a parent
    def getChild(self, name, request):
        if name == '':
            return self
        return Resource.getChild(self, name, request)

    def render_GET(self, request):
        html = "<html>\n" \
                "<head>\n<title>" + str(self._data.connection_count) + " - " + str('{:3}% verified'.format(int(self._data.percent_verified*100))) + "</title>\n"\
                "<meta http-equiv=\"refresh\" content=\"30\">\n</head>" \
                "<body>" + self._data.get_response() + "</body>\n</html>"
        return html

class WebServer:
    def __init__(self, data_handler):
        site = server.Site(RcRoot(data_handler))
        reactor.listenTCP(8330, site)
        print("Started listening on :8330")
