from twisted.internet import reactor

from modules.bitcoinjsonrpc import BitcoinJasonRpc
from modules.config import Config
from modules.util.webdata import WebData
from modules.web import WebServer

__author__ = 'drazisil'

data = None
rpc = None
username = ''
password = ''


if __name__ == "__main__":
    config = Config()
    data = WebData()
    rpc = BitcoinJasonRpc(data, config)
    web = WebServer(data)
    rpc.update_data(5.0)

    reactor.run()
