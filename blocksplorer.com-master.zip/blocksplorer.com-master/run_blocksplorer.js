var server = require('./src/blocksplorer.js');

server.listen(8080);
