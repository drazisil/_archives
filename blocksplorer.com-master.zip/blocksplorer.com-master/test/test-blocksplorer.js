var
  assert = require('assert'),
  http = require('http'),
  server = require('../src/blocksplorer.js'),
  fs = require("fs");
  
var url = 'http://localhost:8080/';

describe('server', function () {

    describe('/', function () {
        before(function () {
            server.listen(8080);
        });

        after(function () {
            server.close();
        });

        
        
        it('should return 200', function (done) {
            http.get(url, function (res) {
                assert.equal(200, res.statusCode);
                done();
            });
        });

        it('should say "hello world"', function (done) {
            http.get(url, function (res) {
                var data = '';

                res.on('data', function (chunk) {
                    data += chunk;
                });

                res.on('end', function () {
                    assert.equal('hello world\n', data);
                    done();
                });
            });
        });
    });  
});
