cpanel-api
===========

a small php class that simplifies api calls to cpanel