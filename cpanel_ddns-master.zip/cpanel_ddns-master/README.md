master: [![Build Status](https://travis-ci.org/drazisil/cpanel_ddns.svg?branch=master)](https://travis-ci.org/drazisil/cpanel_ddns) dev: [![Build Status](https://travis-ci.org/drazisil/cpanel_ddns.svg?branch=dev)](https://travis-ci.org/drazisil/cpanel_ddns) coverage: [![Coverage Status](https://coveralls.io/repos/drazisil/cpanel_ddns/badge.svg?branch=master&service=github)](https://coveralls.io/github/drazisil/cpanel_ddns?branch=master)

cpanel-ddns
===========

A dynamic DNS server that interacts with cpanel
