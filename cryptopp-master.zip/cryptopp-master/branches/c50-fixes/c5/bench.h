#ifndef CRYPTOPP_BENCH_H
#define CRYPTOPP_BENCH_H

#include "cryptlib.h"

void BenchMarkAll(double t=1.0);

#endif
