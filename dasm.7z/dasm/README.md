# dasm

online disassemblier... very work in progress

This will require your Google OAuth credentials file (client_secret.json)