var fs = require('fs');

var oauth = require("./src/oauth/oauth.js");
var driveapi = require("./src/driveapi/driveapi.js");
var dasm = require("./src/dasm/dasm.js");

// Load client secrets from a local file.
fs.readFile('client_secret.json', function processClientSecrets(err, content) {
  if (err) {
    console.log('Error loading client secret file: ' + err);
    return;
  }
  // Authorize a client with the loaded credentials, then call the
  // Drive API.
  oauth.authorize(JSON.parse(content), dasm.init, driveapi.getFile)
});


