var debug = require('debug')('dasm')


var Dasm = function() {
    this.IMAGE_DOS_SIGNATURE = new Buffer(0x4D, 0x5A)
    this.IMAGE_NT_SIGNATURE = new Buffer(0x00, 0x00, 0x45, 0x50)
    this.MACHINE_i386 = new Buffer(0x01, 0x4C)
    this.dateOptions = {
        weekday: "long", year: "numeric", month: "short",
        day: "numeric", hour: "2-digit", minute: "2-digit"
    }
    this.bufFileBytes
    this.fileOffset = 0
    this.NumberOfSections = 0
    this.TimeDateStamp = 0

}

Dasm.prototype.bufFileBytes

// https://msdn.microsoft.com/en-us/library/windows/desktop/aa383751(v=vs.85).aspx
// https://en.wikibooks.org/wiki/X86_Disassembly/Windows_Executable_Files
// https://msdn.microsoft.com/en-us/library/ms809762.aspx
// http://www.csn.ul.ie/~caolan/pub/winresdump/winresdump/doc/pefile2.html
// http://wiki.osdev.org/PE

Dasm.prototype.parseFile = function() {
    var me = module.exports
    // Check if valid DOS file
    me.checkSigDOS()

    // advance past the file signature
    this.fileOffset += 60

    // set fileoffset to start of PE header
    console.log(Dasm.bufFileBytes.indexOf('PE'))
    this.fileOffset = parseInt(me.fetchOffsetDWORD(), 16)
    debug(this.fileOffset)
    me.checkSigNT(me.fetchOffsetDWORD())
    this.fileOffset += 4
    me.checkMachine(me.fetchOffsetWORD())
    this.fileOffset += 2
    this.NumberOfSections = parseInt(me.fetchOffsetWORD(), 16)
    debug('Number of sections: ' + this.NumberOfSections)
    this.fileOffset += 2
    this.TimeDateStamp = new Date(parseInt(me.fetchOffsetDWORD(), 16) * 1000)
    debug('Creation date time stamp: ' + this.TimeDateStamp.toLocaleTimeString("en-us", this.dateOptions))
    console.log(
        Dasm.bufFileBytes[this.fileOffset + 3].toString(16) + ' ' +
        Dasm.bufFileBytes[this.fileOffset + 2].toString(16) + ' ' +
        Dasm.bufFileBytes[this.fileOffset + 1].toString(16) + ' ' +
        Dasm.bufFileBytes[this.fileOffset + 0].toString(16)
    )
    process.exit()
}

/**
 * Return the next 4 bytes from bufFileBytes
 *
 */
function fetchOffsetQWORD() {
    var h =
        bufFileBytes[fileOffset + 7].hexEncode() +
        bufFileBytes[fileOffset + 6].hexEncode() +
        bufFileBytes[fileOffset + 5].hexEncode() +
        bufFileBytes[fileOffset + 4].hexEncode() +
        bufFileBytes[fileOffset + 3].hexEncode() +
        bufFileBytes[fileOffset + 2].hexEncode() +
        bufFileBytes[fileOffset + 1].hexEncode() +
        bufFileBytes[fileOffset + 0].hexEncode()
    debug('fetchOffsetQWORD: ' + h)
    return h
}

/**
 * Return the next 4 bytes from bufFileBytes
 *
 */
Dasm.prototype.fetchOffsetDWORD = function() {
    var h =
        Dasm.bufFileBytes[this.fileOffset + 3].hexEncode() +
        Dasm.bufFileBytes[this.fileOffset + 2].hexEncode() +
        Dasm.bufFileBytes[this.fileOffset + 1].hexEncode() +
        Dasm.bufFileBytes[this.fileOffset + 0].hexEncode()
    debug('fetchOffsetDWORD: ' + h)
    return h
}

/**
 * Return the next 2 bytes from bufFileBytes
 *
 */
Dasm.prototype.fetchOffsetWORD = function() {
    var h =
        Dasm.bufFileBytes[this.fileOffset + 1].hexEncode() +
        Dasm.bufFileBytes[this.fileOffset + 0].hexEncode()
    debug('fetchOffsetWORD: ' + h)
    return h
}

/**
 * Return the next 1 byte from bufFileBytes
 *
 */
Dasm.prototype.fetchOffsetBYTE = function() {
    var h =
        Dasm.bufFileBytes[this.fileOffset + 0].hexEncode()
    debug('fetchOffsetBYTE: ' + h)
    return h
}

/**
 * Check the first two bytes for 'MZ'
 *
 */
Dasm.prototype.checkSigDOS = function() {
    if (Dasm.bufFileBytes.compare(this.IMAGE_DOS_SIGNATURE, 0, 1, 0, 1)) {
        console.log('INFO: Valid executable file loaded...')
    }
    else {
        console.log('ERROR: Not a valid executable file!')
        process.exit(-1)
    }
}

/**
 * Check the for the PE header
 *
 */
Dasm.prototype.checkSigNT = function(peSig) {
    if (new Buffer(peSig).compare(this.IMAGE_NT_SIGNATURE, 0, 3, 0, 3)) {
        console.log('INFO: Valid pe file loaded...')
    }
    else {
        console.log('ERROR: Not a valid pe file!')
        process.exit(-1)
    }
}

/**
 * Check the machine for i386
 *
 */
Dasm.prototype.checkMachine = function(peMachine) {
    if (new Buffer(peMachine).compare(this.MACHINE_i386, 0, 1, 0, 1)) {
        console.log('INFO: Machine type: i386')
    }
    else {
        console.log('ERROR: Machine type not i386: ' + peMachine)
        process.exit(-1)
    }
}

/**
 * Init
 *
 */
Dasm.prototype.init = function(rawData) {
    Dasm.bufFileBytes = rawData
    debug('loaded ' + Dasm.bufFileBytes.byteLength + ' bytes')
    module.exports.parseFile()
}

Number.prototype.hexEncode = function() {
    return ("000" + this.toString(16)).slice(-2);
}

module.exports = new Dasm()