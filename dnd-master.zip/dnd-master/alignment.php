Good: Freedom and kindness.
Lawful Good: Civilization and order.
Evil: Tyranny and hatred.
Chaotic Evil: Entropy and destruction.
Unaligned: Having no alignment; not taking a stand.