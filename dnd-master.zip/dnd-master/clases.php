Class			Role
	Sub Class				Sub Role			Stat Order
----------------------------------------------------------------------------
Cleric			Leader
	Battle Cleric			Melee				STR, WIZ, CHA
	Devoted Cleric			Heal				WIZ, CHA, STR
	Shielding Cleric		Heal				WIZ, CHA, STR
Fighter			Defender
	Battlerage Fighter		Melee				STR, CON, WIZ
	Brawling Fighter		Melee
	Great Weapon Fighter	Melee				STR, CON
	Guardian Fighter		Tank				STR, DEX / WIZ
	Tempest Fighter			Melee				STR, DEX, CON
Paladin			Defender
	Ardent Paladin			Melee				STR, WIZ, CON
	Avenging Paladin		Melee				STR, CHA, WIZ
	Protecting Paladin		Tank				CHA, STR, WIZ
	Virtuous Paladin		Tank				CHA, WIZ, STR
Ranger			Striker
	Archer Ranger			Ranged				DEX, STR, WIZ
	Beastmaster Ranger		Melee				STR, DEX, WIZ
	Hunter Ranger			Ranged/Melee
	Marauder Ranger			Melee/Ranged
	Two-Blade Ranger		Melee				STR, DEX, WIZ
Rogue			Striker
	Aerialist Rogue			Melee				DEX, CHA, STR
	Brawny Rogue			Melee				DEX, STR, CHA
	Cutthoat Rogue			Melee				DEX, CHA, STR
	Shadowy Rogue			Ranged
	Trickster Rogue			Melee				DEX, CHA, STR
Warlock			Striker
	Deceptive Warlock		Ranged				CHA, INT, CON
	Scourge Warlock			Melee/Ranged		CON, INT, CHA
Warlord			Leader
	Bravura Warlord			Melee				STR, CHA, INT
	Insightful Warlord
	Inspiring Warlord		Melee				STR, CHA, INT
	Resorceful Warlord		Melee				STR, INT, CHA
	Skirmishing Warlord		Ranged
	Tactical Warlord		Melee				STR, INT, CHA
Wizard			Controller
	Control Wizard			Ranged				INT, WIZ, DEX
	Illusionist Wizard		Ranged				INT, CHA
	Summoner Wizard			Ranged				INT, CON
	War Wizard			Ranged				INT, DEX, WIZ