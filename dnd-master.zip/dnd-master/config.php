<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

if (file_exists('config_db.php')) {
    @include_once 'config_db.php';
} else {
    // Need to generate config_db.php
    exit;
}

?>
