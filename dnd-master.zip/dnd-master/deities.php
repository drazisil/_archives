Avandra - Good
Bahamut - Lawful Good
Corellon - Unaligned
Erathis - Unaligned
Ioun - Unaligned
Kord - Unaligned
Melora - Unaligned
Moradin - Lawful Good
Pelor - Good
The Raven Queen - Unaligned
Sehanine - Unaligned
Asmodeus - Evil
Bane - Evil
Gruumsh - Chaotic Evil
Lolth - Chaotic Evil
Tiamat - Evil
Torog - Evil
Vecna - Evil
Zehir - Evil