<?php
/*
*	dice.php
*
*	input: $type (4, 6, 8, 10, 12, 20) default: 8
*	input: $count (1-5) optional, default: 1
*	input: $verbose (true/false) optional, default: false
*	output: $result
*/

if (!$_GET['type']) { $type = $_GET['type']; } else { $type = 8; }
if ($_GET['count'] > 0 and $_GET['count'] < 6) { $count = $_GET['count']; } else { $count = 1; }
if (!$_GET['verbose']) { $verbose = TRUE; } else { $verbose = FALSE; }

while ( $count > 0 ) {
	switch ( $type ) {
		case 20:
		case 12:
		case 10:
		case 8:
		case 6:
		case 4:
			$tmp = mt_rand(0, $type);
			echo $type . ': ' . $tmp . ' ; ';
			$result += $tmp;
			break;
		default:
			$tmp = mt_rand(0, 8);
			echo '8: ' . $tmp . ' ; ';
			$result += $tmp;
			break;
	}
	$count--;
}
echo $result;
?>