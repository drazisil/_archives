<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// role, class, subclass, subrole, first stat, second stat, third stat
$playerClasses = array(
    'leader', 'cleric', 'battle cleric', 'melee', 'str', 'wiz', 'cha',
    'leader', 'cleric', 'devoted cleric', 'heal', 'wiz', 'cha', 'str',
    'leader', 'cleric', 'shielding cleric', 'heal', 'wiz', 'cha', 'str',
    'defender', 'fighter', 'battlerage fighter', 'melee', 'str', 'con', 'wiz',
    'defender', 'fighter', 'brawling fighter', 'melee', '', '', '',
    'defender', 'fighter', 'great weapon fighter', 'melee', 'str', 'con', '',
    'defender', 'fighter', 'guardian fighter', 'tank', 'str', 'dex / wiz', '',
    'defender', 'fighter', 'tempest fighter', 'melee', 'str', 'dex', 'con',
    'defender', 'paladin', 'ardent paladin', 'melee', 'str', 'wiz', 'con',
    'defender', 'paladin', 'avenging paladin', 'melee', 'str', 'cha', 'wiz',
    'defender', 'paladin', 'protecting paladin', 'tank', 'cha', 'str', 'wiz',
    'defender', 'paladin', 'virtuous paladin', 'tank', 'cha', 'wiz', 'str',
    'striker', 'ranger', 'archer ranger', 'ranged', 'dex', 'str', 'wiz',
    'striker', 'ranger', 'beastmaster ranger', 'melee', 'str', 'dex', 'wiz',
    'striker', 'ranger', 'hunter ranger', 'ranged / melee', '', '', '',
    'striker', 'ranger', 'marauder ranger', 'melee / ranged', '', '', '',
    'striker', 'ranger', 'two-blade ranger', 'melee', 'str', 'dex', 'wiz',
    'striker', 'rogue', 'aerialist rogue', 'melee', 'dex', 'cha', 'str',
    'striker', 'rogue', 'brawny rogue', 'melee', 'dex', 'str', 'cha',
    'striker', 'rogue', 'cutthoat rogue', 'melee', 'dex', 'cha', 'str',
    'striker', 'rogue', 'shadowy rogue', 'ranged', '', '', '',
    'striker', 'rogue', 'trickster rogue', 'melee', 'dex', 'cha', 'str',
    'striker', 'warlock', 'deceptive warlock', 'ranged', 'cha', 'int', 'con',
    'striker', 'warlock', 'scourge warlock', 'melee / ranged', 'con', 'int', 'cha',
    'leader', 'warlord', 'bravura warlord', 'melee', 'str', 'cha', 'int',
    'leader', 'warlord', 'insightful warlord', '', '', '', '',
    'leader', 'warlord', 'inspiring warlord', 'melee', 'str', 'cha', 'int',
    'leader', 'warlord', 'resorceful warlord', 'melee', 'str', 'int', 'cha',
    'leader', 'warlord', 'skirmishing warlord', 'ranged', '', '', '',
    'leader', 'warlord', 'tactical warlord', 'melee', 'str', 'int', 'cha',
    'controller', 'wizard', 'control wizard', 'ranged', 'int', 'wiz', 'dex',
    'controller', 'wizard', 'illusionist wizard', 'ranged', 'int', 'cha', '',
    'controller', 'wizard', 'summoner wizard', 'ranged', 'int', 'con', '',
    'controller', 'wizard', 'war wizard', 'ranged', 'int', 'dex', 'wiz',
);
?>
