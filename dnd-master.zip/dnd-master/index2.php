<!DOCTYPE html>
<html>
    <head>
        <title></title>
    </head>
    <body id="body">
        <div>
            <form>
                <label>Pick a class: 
                    <select id="selClass">
                        <optgroup label="Controller">
                            <option value="wizard">Wizard
                        <optgroup label="Defender">
                            <option value="fighter">Fighter
                            <option value="paladin">Paladin
                        <optgroup label="leader">
                            <option value="cleric">Cleric
                            <option value="warlord">Warlord
                        <optgroup label="Striker">
                            <option value="ranger">Ranger
                            <option value="rogue">Rogue
                            <option value="warlock">Warlock
                    </select>  
                </label>
            </form>
        </div>
        <footer>
            Dungeons &amp; Dragons is &copy;1995-2011 Wizards of the Coast LLC, a subsidiary of Hasbro, Inc. All Rights Reserved
        </footer>
    </body>
</html>