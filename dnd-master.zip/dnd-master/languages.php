Common - Humans, halflings, tieflings - Common
Deep Speech - Mind flayers, githyanki, kuo-toas - Rellanic
Draconic - Dragons, dragonborn, kobolds - Iokharic
Dwarven - Dwarves, azer - Davek
Elven - Elves, eladrin, fomorians - Rellanic
Giant - Giants, orcs, ogres - Davek
Goblin - Goblins, hobgoblins, bugbears - Common
Primordial - Efreets, archons, elementals - Barazhad
Supernal - Angels, devils, gods - Supernal
Abyssal - Demons, gnolls, sahuagin - Barazhad