Dragonborn
Dwarves
Eladrin
Elves
Half-elves
Halflings
Humans
Tieflings