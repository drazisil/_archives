Controller (Wizard)
Defender (Fighter, Paladin)
Leader (Cleric, Warlord)
Striker (Ranger, Rogue, Warlock)