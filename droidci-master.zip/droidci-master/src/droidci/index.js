const fs = require('fs')

// FUNCTIONS

function checkPlatform() {
  switch (process.platform) {
    case 'darwin':
    case 'linux':
      return true
    default:
      return false
  }
}

function getSDKPath() {
  return process.env.ANDROID_HOME
}

function getAVDPath(platform) {
  var user = process.env.USER
  switch (platform) {
    case 'darwin':
      return `/Users/${user}/.android/avd`
    case 'linux':
      return `/home/${user}/.android/avd`
    default:
      return undefined
  }

}

function getAVDs(avdPath) {
  var avds = ls(avdPath).filter(function(item){
  return item.indexOf('.ini') == -1})

  for (var i in avds) {
    avds[i] = avds[i].split('.', 1)[0]
  }

  return avds
}

function getArgs() {
  process.argv.shift()
  process.argv.shift()
  return process.argv
}

function printUsage() {
  console.log('Do you know how to use this?')
  process.exit()
}

function ls(path) {
  return fs.readdirSync(path)
}

module.exports = {
  checkPlatform: checkPlatform,
  getSDKPath: getSDKPath,
  getAVDPath: getAVDPath,
  getAVDs: getAVDs,
  getArgs: getArgs,
  printUsage,
  ls: ls
}