# fakebitcoind
A Python-based fake Bitcoin daemon for testing RPC calls when a node is not availiable
