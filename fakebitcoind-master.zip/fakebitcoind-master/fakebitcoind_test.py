import random
import unittest

class TestSequenceFunctions(unittest.TestCase):

    def setUp(self):
        moo = 'fish'

    def test_is_true(self):
        # make sure the shuffled sequence does not lose any elements
        self.assertEqual(1, 1)

if __name__ == '__main__':
    unittest.main()