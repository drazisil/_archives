# fun
I need some fun

git hooks need to be chmod +x
