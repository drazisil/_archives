package com.drazaisil.gameEngine;

import org.lwjgl.input.Keyboard;

public class Game {

    public Game(){

    }

    public void input(){

        if (Input.getKeyDown(Keyboard.KEY_UP)) {
            System.out.println("We just pressed up");
        }

        if (Input.getKeyup(Keyboard.KEY_UP)) {
            System.out.println("We just released up");
        }

        if (Input.getMouseDown(1)) {
            System.out.println("We just clicked 1");
        }

        if (Input.getMouseUp(1)) {
            System.out.println("We just unclicked 1");
        }


    }

    public void update(){

    }

    public void render(){

    }
}


