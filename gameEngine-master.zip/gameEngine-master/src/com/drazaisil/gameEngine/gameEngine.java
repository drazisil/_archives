package com.drazaisil.gameEngine;

import org.lwjgl.opengl.GL11;

import java.io.File;

public class gameEngine {

    public static final int WIDTH = 1024;
    public static final int HEIGHT = 768;
    public static final String TITLE = "3d Game Engine";
    public static final double FRAME_CAP = 5000.0;

    private boolean isRunning;
    private Game game;

    private gameEngine() {
        game = new Game();
        Window.createWindow(WIDTH, HEIGHT, TITLE);
        isRunning = false;
        run();
        stop();
    }

    public void start(){

        if (isRunning){
            return;
        }

        this.isRunning = true;

    }

    public void stop(){

        if (!isRunning){
            return;
        }

        this.isRunning = false;
    }

    private void run(){

        System.out.println("OpenGL version: " + GL11.glGetString(GL11.GL_VERSION));

        int frames = 0;
        long frameCount;

        isRunning = true;

        final double frameTime = 1.0 / FRAME_CAP;

        long lastTime = Time.getTime();
        double unprocessedTime = 0;

        while (isRunning()) {

            boolean render = false;

            long startTime = Time.getTime();
            long passedTime = startTime - lastTime;
            lastTime = startTime;

            unprocessedTime += passedTime / (double)Time.SECOND;
            frameCount = passedTime;

            while (unprocessedTime > frameTime){

                render = true;

                unprocessedTime -= frameTime;

                if (Window.isCloseRequested()) {
                    stop();

                }

                Time.setDelta(frameTime);
                Input.update();

                game.input();
                game.update();

                if (frameCount >= Time.SECOND){
                    System.out.println(frames);
                    frames = 0;
                    frameCount = 0;
                }

                if (render){
                    render();
                    frames++;
                } else {
                    try {
                        Thread.sleep(1);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }


        }

        cleanup();

    }

    /**
     * @return boolean
     */
    private boolean isRunning() {
        return this.isRunning;
    }

    private void render(){
        game.render();
        Window.render();
    }

    private void cleanup() {
        Window.close();

    }

    public static void main(String[] args) {
        System.setProperty("org.lwjgl.librarypath", new File("lib/natives").getAbsolutePath());
        new gameEngine();
    }
}
