jReader
=======

A php/js feed reader
