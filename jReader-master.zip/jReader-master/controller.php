<?php

// Report all PHP errors
error_reporting(-1);

function __autoload($class_name) {
    include 'modules/' . $class_name . '.php';
}

switch ($_REQUEST['module']) {
    case 'feeds':

        switch ($_REQUEST['action']) {
            case 'fetch':
                $feedURL = $_REQUEST['feedURL'];
                $feedObj = new feed();
                $feedObj->fetch($feedURL);
                echo $feedObj->_get("feedType")."<br>";
                
                break;

            default:
                break;
        }
        break;

    default:
        break;
}
?>
