<?php 
phpinfo();
?>
