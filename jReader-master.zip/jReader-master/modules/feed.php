<?php

/**
 * Description of feed
 *
 * @author Joseph
 */
class feed {

    /**
     * Contains the URL of the feed
     * @var string 
     */
    private $feedFetchURL;

    /**
     * Contacvts the contents of the feed
     * @var string
     */
    private $feedData;

    /**
     * Contains the type of feed
     * @var string 
     */
    private $feedType;

    /**
     * Contains the RSS version if feedType = RSS
     * @var string 
     */
    private $feedRSSVersion;

    /**
     * Contains the time the cache was last updated
     * @var type datetime
     */
    private $feedCacheTimestamp;

    /**
     * Contains the last time the feed was updated
     * @var datetime 
     */
    private $feedLastUpdateTimestamp;

    /**
     * Fetches the feed, either from cache or from the server
     * @param string $feedID
     */
    function fetch($feedID) {
        $this->feedFetchURL = $feedID;

        \date_default_timezone_set('America/Chicago');
        //TODO: Check if a cached copy exists
        $this->feedCacheTimestamp = new \DateTime();

// create a new cURL resource
        $ch = \curl_init();

// set URL and other appropriate options
        \curl_setopt($ch, CURLOPT_URL, $this->feedFetchURL);
        \curl_setopt($ch, CURLOPT_HEADER, 0);
        \curl_setopt($ch, CURLOPT_USERAGENT, 'jReader; (+http://jeader.jwebnet.net; feed-url=' . $this->feedFetchURL . ')');
        \curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        \curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

// grab URL and pass it to the browser
        $feedUnreplaced = curl_exec($ch);
        $feed = \str_replace("\r\n", "\n", $feedUnreplaced);
        $feedArr = \explode("\n", $feed);
        $matches = array();
        \preg_match("/version=[\"]?([0-9\.]*)[\"]?/", $feed, $matches);
        if (!isset($matches[1])) {
            $this->feedType = 'Invalid';
        }
        $this->feedType = 'RSS';
        print_r($matches);
        $this->feedRSSVersion = $matches[1];
        //print_r($feed);
// close cURL resource, and free up system resources
        \curl_close($ch);
        $this->isNewerThenCache();
    }

    /**
     * Checks if feedLastUpdateTimestamp is newer then feedFetchTime
     */
    function isNewerThenCache() {
        \date_default_timezone_set('America/Chicago');
        $h = \get_headers($this->feedFetchURL, 1);
        $this->feedLastUpdateTimestamp = new \DateTime($h['Last-Modified'][0]);

        $interval = $this->feedCacheTimestamp->diff($this->feedLastUpdateTimestamp);
        if ($interval->i > 0) {
            echo 'Newer then cache';
            return TRUE;
        } else {
            echo 'Cache is still current';
            return TRUE;
        }
        echo $interval->format("%i");
    }

    function _get($param) {
        return $this->$param;
    }

}

?>
