js-bitcoin-rpc
==============

A Javascript CORS-compliant Bitcoin library.

Requires a CORS-compliant server or proxy, such as [pyBitcoinRpcProxy](https://github.com/drazisil/pyBitcoinRpcProxy)


