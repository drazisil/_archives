/**
 * Created by joseph on 9/15/2014.
 * rename this file to config.RpcServer.js
 */

/**
 *
 * hostname for the bitcoin rpc server
 * @example 'http://localhost:8330'
 * @type {string}
 */
const BITCOINRPC_HOST = "";
/**
 * username for the bitcoin rpc server
 * @type {string}
 */
const BITCOINRPC_USERNAME = "";
/**
 * password for the bitcoin rpc server
 * @type {string}
 */
const BITCOINRPC_PASSWORD = "";

