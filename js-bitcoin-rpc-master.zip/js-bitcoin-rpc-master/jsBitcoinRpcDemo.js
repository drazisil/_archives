/**
 * Created by joseph on 9/15/2014.
 */

function runDemo() {
    jsBitcoinRpc.testConnection();
    return false;
}
