<?php
/* This file contains the values needed for testing
*  Change as needed and rename to config.php */
$configRpcUser = 'bitcoinrpc';
$configRpcPass = '123';
$configRpcHost = '127.0.0.1';
$configRpcPort = '18332';