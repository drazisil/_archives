# README

This is mainly a training exercise. It is partly to update jwebgen.com, but it is more geared towards teaching me newer technologies then what I built the site in originally.

* Run in a Docker container

Docker is going to be a big part of my life. The original jwebgen was built on a shared web host, the new version will be on a dedicated box that can support containers. In addition, the server currently is running several others services, including one in a container. Therefore, it makes sense to place the new app in one too.

* Use Rails for the backend

Ruby is a lovely language I'm already partly in love with, despite having barely touched it. On the shared host, I was limited to only a few gems, and not even sure how to launch a Rails app. In addition, the old site was written in PHP, and is a massive monolith of code, consisting of only a few files, and nearly impossible to update, despite several attempts at refactoring.

* Use Angular for the frontend

This is something I tried to do on a prior attempt, but due to the aformentioned codebase being hard wired into the frontend, it proved to be very difficault. Be decopling them and using JSON to pase data, I can use Angular and Bootstrap to create a responsivle frontend. In addition, I will hopefully be able to create a mobile friendly view, a frequestly requested feature

* Make everything an object

This is something that was attempted with PHP, but will be much cleaner and manageable with Ruby.

========================

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
