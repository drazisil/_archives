require 'rails_helper'

driver = Selenium::WebDriver.for :firefox

RSpec.describe "welcome/index.html.erb", type: :view do
  it "puts the data received from the server on the page" do
    driver.navigate.to 'http://localhost:8080'

    span = driver.find_element(:id, 'footer-wip')
    expect(span.text).to eq("WIP")

  end
end