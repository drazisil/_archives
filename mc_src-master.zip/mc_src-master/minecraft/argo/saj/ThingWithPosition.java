package argo.saj;

interface ThingWithPosition
{
    int getColumn();

    int getRow();
}
