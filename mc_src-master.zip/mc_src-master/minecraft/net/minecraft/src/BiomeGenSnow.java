package net.minecraft.src;

public class BiomeGenSnow extends BiomeGenBase
{
    public BiomeGenSnow(int par1)
    {
        super(par1);
    }
}
