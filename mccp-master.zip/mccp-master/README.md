# MCCP

A Python 2.7.9 Minecraft server manager

Linux only

Current internal commands:
---------------------------
* /start
* /status
* /stop (overrides stop)
* /restart
* /quit

Very WIP.

To install twisted, you will need to have the linux kernel headers installed.
Please reference your distribution's documention, or the internet, if you have issues.

Installing
---------------
* `sudo [apt-get/yum] install python-dev python-pip` This step may not be needed, please use your distro's packagemanager to install python-pip if these steps do not work for you.
* `sudo pip install twisted`
* `git clone https://github.com/drazisil/mccp.git`

Credits
-----------------
* Thank you very much to Briana Rezendes for the color help
