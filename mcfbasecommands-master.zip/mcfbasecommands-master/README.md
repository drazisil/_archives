# MCFBaseCommands 

##Version 0.4.0-alpha

Provides some base commands to Minecraft Forge servers

Built under java 1.7

Commands:

* /fly
* /spawn
* /back
