package com.drazisil.mcfbasecommands;

import com.drazisil.mcfbasecommands.proxy.MCFCommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = MCFBaseCommands.MODID, name = MCFBaseCommands.NAME, version = MCFBaseCommands.VERSION,
        acceptableRemoteVersions = "*", acceptedMinecraftVersions = "1.8.*")
public class MCFBaseCommands
{
    public static final String MODID = "mcfbasecommands";
    public static final String NAME = "MCFBaseCommands";
    public static final String VERSION = "0.4.0-alpha";

    @SidedProxy(clientSide = "com.drazisil.mcfbasecommands.proxy.MCFClientProxy",
            serverSide = "com.drazisil.mcfbasecommands.proxy.MCFDedicatedServerProxy")
    public static MCFCommonProxy proxy;

    @EventHandler
    public void preInitialization(FMLPreInitializationEvent event) {
        proxy.preInit(event);
    }

    @EventHandler
    public void serverLoad(FMLServerStartingEvent event) {
        proxy.serverLoad(event);
    }

}
