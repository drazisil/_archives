/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfbasecommands.command;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;

import java.util.Collections;
import java.util.List;

public class CommandFly extends CommandBase {

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel() {
        return 4;
    }

    @Override
    public String getName() {
        return "fly";
    }

    /**
     * Gets a list of aliases for this command
     */
    public List getAliases() {
        return Collections.singletonList("fly");
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/fly\n" +
                "/fly <player>";
    }

    @Override
    public void execute(ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 2) {
            if (args.length == 0) {
                /*
                Was command issues by a player?
                 */
                if (sender instanceof EntityPlayerMP) {

                    PlayerCapabilities capabilities = ((EntityPlayerMP) sender).capabilities;
                    if (capabilities.allowFlying) {
                        capabilities.allowFlying = false;
                        capabilities.isFlying = false;
                        ((EntityPlayerMP) sender).sendPlayerAbilities();
                        sender.addChatMessage(new ChatComponentText("Your wings have been clipped."));
                        ((EntityPlayerMP) sender).jump();
                        ((EntityPlayerMP) sender).jump();
                    } else {
                        capabilities.allowFlying = true;
                        capabilities.isFlying = true;
                        ((EntityPlayerMP) sender).sendPlayerAbilities();

                        sender.addChatMessage(new ChatComponentText("You can fly, you can fly, you can fly!"));
                    }

                } else {
                    /*
                    Console can't fly...or can it?
                     */
                    sender.addChatMessage(new ChatComponentText("Silly console! You can't fly. Did you mean fly <player>?"));
                }
            } else if (args.length == 1 && args[0].equals("check")){
                if (sender instanceof EntityPlayer) {
                    PlayerCapabilities capabilities = ((EntityPlayer) sender).capabilities;
                    if (capabilities.allowFlying){
                        sender.addChatMessage(new ChatComponentText("I'm free like a bird!"));
                    } else {
                        sender.addChatMessage(new ChatComponentText("Oh how I with I could fly..."));
                    }
                }

            }

        } else {
            // Not a valid command syntax
            sender.addChatMessage(new ChatComponentText("Not enough values. Please see help."));
        }
    }

    @Override
    public boolean canCommandSenderUse(ICommandSender sender) {
        return sender.canUseCommand(this.getRequiredPermissionLevel(), this.getName());
    }

    public List addTabCompletionOptions(ICommandSender sender, String[] args, BlockPos pos)
    {
        return args.length == 1 ? getListOfStringsMatchingLastWord(args, this.getListOfPlayerUsernames()) : null;
    }

    /**
     * Returns String array containing all player usernames in the server.
     */
    protected String[] getListOfPlayerUsernames()
    {
        return MinecraftServer.getServer().getAllUsernames();
    }



}
