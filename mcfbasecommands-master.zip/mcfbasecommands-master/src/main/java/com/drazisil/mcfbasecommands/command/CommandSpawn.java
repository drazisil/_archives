/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfbasecommands.command;

import com.drazisil.mcfbasecommands.playerdatahandler.PlayerDataHandler;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.BlockPos;

public class CommandSpawn extends CommandBase {

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel() {
        return 0;
    }

    @Override
    public String getName() {
        return "spawn";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/spawn";
    }

    @Override
    public void execute(ICommandSender sender, String[] args) throws CommandException {
        if (sender instanceof EntityPlayerMP){
            /**
            Get player's current position
             */
            BlockPos senderPosition = sender.getPosition();

            /**
             * Save current position for use in /back
             */
            PlayerDataHandler playerDataHandler = new PlayerDataHandler();
            playerDataHandler.setLastPos((EntityPlayer) sender, senderPosition);

            /**
             * Move player to spawn
             */
            BlockPos spawnPos = sender.getEntityWorld().getSpawnPoint();
            ((EntityPlayerMP) sender).setPositionAndUpdate(spawnPos.getX(),spawnPos.getY(),spawnPos.getZ());
        }


    }
}
