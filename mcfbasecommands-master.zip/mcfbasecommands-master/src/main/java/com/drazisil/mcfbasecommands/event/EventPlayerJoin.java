/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfbasecommands.event;

import com.drazisil.mcfbasecommands.MCFBaseCommands;
import com.drazisil.mcfbasecommands.playerdatahandler.PlayerDataHandler;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.util.BlockPos;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class EventPlayerJoin {
    protected static final Logger logger = LogManager.getLogger(MCFBaseCommands.MODID);

        public void register() {
            MinecraftForge.EVENT_BUS.register(this);
        }

        @SubscribeEvent
        public void OnEntityJoinWorld(EntityJoinWorldEvent event) {
            if (event.entity instanceof EntityPlayer){
                /**
                If player is flying, turn flying on
                 */
                int curY = event.entity.getPosition().getY();
                int topY = event.entity.worldObj.getTopSolidOrLiquidBlock(event.entity.getPosition()).getY();

                /**
                 * Save position as /back
                 * TODO: check if player is allowed flying and save accordingly
                 */
                BlockPos senderPosition = event.entity.getPosition();
                PlayerDataHandler playerDataHandler = new PlayerDataHandler();
                playerDataHandler.setLastPos((EntityPlayer) event.entity, senderPosition);


                /**
                Anything about 3 blocks is considered flying since onGround can't be trusted.
                 */
                if ((curY - topY) > 3){
                    PlayerCapabilities capabilities = ((EntityPlayer) event.entity).capabilities;
                    capabilities.isFlying = true;
                    capabilities.allowFlying = true;
                    ((EntityPlayer) event.entity).sendPlayerAbilities();
                    //event.entity.addChatMessage(new ChatComponentText("You can fly, you can fly, you can fly!"));
                }
            }
        }
    }

