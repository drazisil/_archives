/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfbasecommands.playerdatahandler;

import com.drazisil.mcfbasecommands.MCFBaseCommands;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.BlockPos;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PlayerDataHandler {

    protected static final Logger logger = LogManager.getLogger(MCFBaseCommands.MODID);

    private static final String COMPOUND = MCFBaseCommands.MODID;

    public BlockPos getLastPos(EntityPlayer player) {
        NBTTagCompound cmp = getCompoundToSet(player);
        if (cmp.hasKey("lastPosX") && cmp.hasKey("lastPosY") && cmp.hasKey("lastPosZ")){
            return new BlockPos(cmp.getInteger("lastPosX"), cmp.getInteger("lastPosY"), cmp.getInteger("lastPosZ"));
        }
        return player.getPosition();
    }

    public NBTTagCompound getP2PData(EntityPlayer player){
        NBTTagCompound cmp = getCompoundToSet(player);
        if (cmp.hasKey("p2p")){
            return cmp.getCompoundTag("p2p");
        }
        return null;

    }

    public void setP2PFrom(EntityPlayer player, EntityPlayer targetPlayer){
        setP2PStatus(player, targetPlayer, "from");
    }

    public void setP2PTo(EntityPlayer player, EntityPlayer targetPlayer){
        setP2PStatus(player, targetPlayer, "to");
    }

    private void setP2PStatus(EntityPlayer player, EntityPlayer targetPlayer, String direction){
        /**
         * This is a request for targetPlayer to come visit player
         */
        if (direction.equals("from")){
            NBTTagCompound cmp = getCompoundToSet(targetPlayer);
            NBTTagCompound p2p = new NBTTagCompound();
            BlockPos playerPos = player.getPosition();
            cmp.setString("direction", "from");
            cmp.setInteger("requestCounter", 1800);
            cmp.setInteger("targetPosX", playerPos.getX());
            cmp.setInteger("targetPosY", playerPos.getY());
            cmp.setInteger("targetPosZ", playerPos.getZ());
            cmp.setTag("p2p", p2p);
        } else {
            /**
             * This is a request for player to visit targetPlayer
             */
            NBTTagCompound cmp = getCompoundToSet(targetPlayer);
            NBTTagCompound p2p = new NBTTagCompound();
            BlockPos targetPlayerPos = targetPlayer.getPosition();
            cmp.setString("direction", "to");
            cmp.setInteger("requestCounter", 1800);
            cmp.setInteger("targetPosX", targetPlayerPos.getX());
            cmp.setInteger("targetPosY", targetPlayerPos.getY());
            cmp.setInteger("targetPosZ", targetPlayerPos.getZ());
            cmp.setTag("p2p", p2p);
        }
    }

    public void setLastPos(EntityPlayer player, BlockPos lastPos) {
        NBTTagCompound cmp = getCompoundToSet(player);
        cmp.setInteger("lastPosX", lastPos.getX());
        cmp.setInteger("lastPosY", lastPos.getY());
        cmp.setInteger("lastPosZ", lastPos.getZ());

    }

    private static NBTTagCompound getCompoundToSet(EntityPlayer player) {
        NBTTagCompound cmp = player.getEntityData();
        if (!cmp.hasKey(COMPOUND))
            cmp.setTag(COMPOUND, new NBTTagCompound());

        return cmp.getCompoundTag(COMPOUND);
    }
}