/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfbasecommands.proxy;

import com.drazisil.mcfbasecommands.MCFBaseCommands;
import com.drazisil.mcfbasecommands.command.CommandBack;
import com.drazisil.mcfbasecommands.command.CommandFly;
import com.drazisil.mcfbasecommands.command.CommandSpawn;
import com.drazisil.mcfbasecommands.event.EventLivingUpdate;
import com.drazisil.mcfbasecommands.event.EventPlayerJoin;
import net.minecraft.command.ServerCommandManager;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MCFCommonProxy {
    protected static final Logger logger = LogManager.getLogger(MCFBaseCommands.MODID);

    public boolean isClient() {
        return false;
    }

    public void preInit(FMLPreInitializationEvent event) {
        // Not currently using events at the global level, but leaving the code for reference
        //FMLCommonHandler.instance().bus().register(events);
        //MinecraftForge.EVENT_BUS.register(events);

        EventPlayerJoin eventPlayerJoin = new EventPlayerJoin();
        eventPlayerJoin.register();

        EventLivingUpdate eventLivingUpdate = new EventLivingUpdate();
        eventLivingUpdate.register();

        // Get the configuration
        Configuration config = new Configuration(event.getSuggestedConfigurationFile());

        config.load();

        config.save();
    }

    public void serverLoad(FMLServerStartingEvent event) {

        ServerCommandManager commandManager = (ServerCommandManager) event.getServer().getCommandManager();
        commandManager.registerCommand(new CommandFly());
        commandManager.registerCommand(new CommandSpawn());
        commandManager.registerCommand(new CommandBack());

    }

}