# mcfperms

A Forge 1.8 permissions mod

Built under java 1.7

Commands:
* [Wiki](https://github.com/drazisil/mcfperms/wiki/commands)

Uses [YAMLBeans 1.09](https://github.com/EsotericSoftware/yamlbeans/releases/tag/yamlbeans-1.09)  for YAML access

Reference: 
* [PEX File format](https://github.com/PEXPlugins/PermissionsEx/wiki/Pex-basics#permissions-hierarchy-top)
* [YAML 1.2](http://www.yaml.org/spec/1.2/spec.html)
