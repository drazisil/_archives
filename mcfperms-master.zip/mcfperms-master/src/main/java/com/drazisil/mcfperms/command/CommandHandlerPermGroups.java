/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfperms.command;

import com.drazisil.mcfperms.permissions.PermissionsManager;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

class CommandHandlerPermGroups {
    public CommandHandlerPermGroups(PermissionsManager p, ICommandSender sender, String[] args) {
        String groupName = args[1];
        if (args.length == 5) {

            if (args[2].equals("permission")) {
                if (args[3].equals("add")) {
                    // perm group <group> permission add <permission>
                    String permissionNode = args[4];
                    if (p.addGroupPermission(groupName, permissionNode)) {
                        sender.addChatMessage(new ChatComponentText(permissionNode + " added to " + groupName));
                    } else {
                        sender.addChatMessage(new ChatComponentText("Unable to add " + permissionNode + " to " + groupName));
                    }
                } else if (args[3].equals("remove")) {
                    // perm group <group> permission remove <permission>
                    String permissionNode = args[4];
                    if (p.removeGroupPermission(groupName, permissionNode)) {
                        sender.addChatMessage(new ChatComponentText(permissionNode + " removed from " + groupName));
                    } else {
                        sender.addChatMessage(new ChatComponentText("Unable to remove " + permissionNode + " from " + groupName));
                    }
                } else if (args[3].equals("check")) {
                    // perm group <group> permission check <permission>
                    String permissionNode = args[4];
                    if (p.checkGroupPermission(groupName, permissionNode)) {
                        sender.addChatMessage(new ChatComponentText(groupName + " has " + permissionNode));
                    } else {
                        sender.addChatMessage(new ChatComponentText(groupName + " has " + permissionNode));
                    }
                }
            }
        }
    }

}
