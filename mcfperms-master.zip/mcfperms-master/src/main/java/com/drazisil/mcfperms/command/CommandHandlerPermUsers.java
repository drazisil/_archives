/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfperms.command;

import com.drazisil.mcfperms.permissions.PermissionsManager;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

class CommandHandlerPermUsers {
    public CommandHandlerPermUsers(PermissionsManager p, ICommandSender sender, String[] args) {

        String userName = args[1];
        if (args.length == 5) {
        if (args[2].equals("permission")) {
            if (args[3].equals("add")) {
                // perm user <user> permission add <permission>
                String permissionNode = args[4];
                if (p.addUserPermission(userName, permissionNode)) {
                    sender.addChatMessage(new ChatComponentText(permissionNode + " added to " + userName));
                } else {
                    sender.addChatMessage(new ChatComponentText("Unable to add " + permissionNode + " to " + userName));
                }
            } else if (args[3].equals("remove")) {
                // perm user <user> permission remove <permission>
                String permissionNode = args[4];
                if (p.removeUserPermission(userName, permissionNode)) {
                    sender.addChatMessage(new ChatComponentText(permissionNode + " removed from " + userName));
                } else {
                    sender.addChatMessage(new ChatComponentText("Unable to remove " + permissionNode + " from " + userName));
                }
            } else if (args[3].equals("check")) {
                // perm user <user> permission check <permission>
                String permissionNode = args[4];
                if (p.checkUserPermission(userName, permissionNode)) {
                    sender.addChatMessage(new ChatComponentText(userName + " has " + permissionNode));
                } else {
                    sender.addChatMessage(new ChatComponentText(userName + " does not have " + permissionNode));
                }
            }
        } else if (args[2].equals("group")) {
            if (args[3].equals("add")) {
                // perm user <user> permission add <permission>
                String groupName = args[4];
                if (p.addGroup(userName, groupName)) {
                    sender.addChatMessage(new ChatComponentText(groupName + " added to " + userName));
                } else {
                    sender.addChatMessage(new ChatComponentText("Unable to add " + groupName + " to " + userName));
                }
            } else if (args[3].equals("remove")) {
                // perm user <user> permission remove <permission>
                String groupName = args[4];
                /*
                We currently don't want the default group being removed from users
                 */
                if (groupName.equals("default")) {
                    sender.addChatMessage(new ChatComponentText("Deleting the default group from users is not permitted."));
                    return;
                }
                if (p.removeGroup(userName, groupName)) {
                    sender.addChatMessage(new ChatComponentText(groupName + " removed from " + userName));
                } else {
                    sender.addChatMessage(new ChatComponentText("Unable to remove " + groupName + " from " + userName));
                }
            } else if (args[3].equals("check")) {
                // perm user <user> permission check <permission>
                String groupName = args[4];
                if (p.checkGroup(userName, groupName)) {
                    sender.addChatMessage(new ChatComponentText(userName + " has " + groupName));
                } else {
                    sender.addChatMessage(new ChatComponentText(userName + " does not have " + groupName));
                }
            }
        }
        }

    }
}
