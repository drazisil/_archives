/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfperms.command;

import com.drazisil.mcfperms.permissions.PermissionsManager;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CommandMCFPerms extends CommandBase {

    private final PermissionsManager pm = new PermissionsManager();

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel() {
        return 4;
    }

    @Override
    public String getName() {
        return "perm";
    }

    /**
     * Gets a list of aliases for this command
     */
    public List getAliases() {
        return Collections.singletonList("perm");
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "\n/perm user <player> permission add <permission>\n"
                + "/perm user <player> permission remove <permission>\n"
                + "/perm user <player> permission check <permission>\n"
                + "/perm user <player> group add <group>\n"
                + "/perm user <player> group remove <group>\n"
                + "/perm user <player> group check <group>\n"
                + "/perm group <group> permission add <permission\n>"
                + "/perm group <group> permission remove <permission>\n"
                + "/perm group <group> permission check <permission>\n";
    }

    @Override
    public void execute(ICommandSender sender, String[] args) throws CommandException {
        /*
         * 2 args
         * perm list [user/group]
         *
         * 4 args
         * perm user <user> group list
         * perm group <group> user list
         *
         * 5 args
         * [Done] perm [user/group] [<user>/<group>] permission [add/remove/check] <permission>
         * [Done] perm [user/group] [<user>/<group>] permission list
         * perm user <user> group [add/remove/check] <group>
         */
        pm.init();

        if (!(args.length == 5 || args.length == 4 || args.length == 2)) {

            // Not a valid command syntax
            sender.addChatMessage(new ChatComponentText("Not enough values. Please see help."));
        }

        // Start small, work way up

        if (args.length == 2 && args[0].equals("list")) {
            // perm list [user/group]
            String type = args[1].toLowerCase();

            if (type.equals("users")) {
                ArrayList<String> users = pm.getUserList();
                if (!users.isEmpty()) {
                    sender.addChatMessage(new ChatComponentText("There are the following users: " + users.toString()));
                } else {
                    sender.addChatMessage(new ChatComponentText("There are no users found."));
                }
            } else if (type.equals("groups")) {
                ArrayList<String> groups = pm.getGroupList();
                if (!groups.isEmpty()) {
                    sender.addChatMessage(new ChatComponentText("There are the following groups: " + groups.toString()));
                } else {
                    sender.addChatMessage(new ChatComponentText("There are no groups found."));
                }

            } else {
                // Not a valid command syntax
                sender.addChatMessage(new ChatComponentText("Not a valid type. Please see help."));
            }
            return;
        }

        if (args.length == 4
                && (args[0].equals("user")
                || args[0].equals("group"))) {
            // The first arg is the group we are acting on [user/group]
            String type = args[0];

            // Check that group is valid
            if (!(type.equals("user")
                    || type.equals("group"))) {

                // Not a valid command group
                sender.addChatMessage(new ChatComponentText("Invalid command group. Please see help."));

            }

            if (type.equals("user")) {
                String userName = args[1];
                if (args[2].equals("permission") && args[3].equals("list")) {
                    // perm user <user> permission list
                    ArrayList<String> permissionsList = pm.getUserPermissions(userName);
                    if (!permissionsList.isEmpty()) {
                        sender.addChatMessage(new ChatComponentText(userName + " has the following permissions: " + permissionsList.toString()));
                    } else {
                        sender.addChatMessage(new ChatComponentText(userName + " does not have any permissions."));
                    }

                } else if (args[2].equals("group") && args[3].equals("list")) {
                    // perm user <user> group list
                    ArrayList<String> groupsList = pm.getUserGroups(userName);
                    if (!groupsList.isEmpty()) {
                        sender.addChatMessage(new ChatComponentText(userName + " has the following groups: " + groupsList.toString()));
                    } else {
                        sender.addChatMessage(new ChatComponentText(userName + "is not a member of any groups."));
                    }
                }

            } else if (type.equals("group")) {
                String groupName = args[1];
                // perm group <user> permission list
                if (args[2].equals("permission") && args[3].equals("list")) {
                    ArrayList<String> permissionsList = pm.getGroupPermissions(groupName);
                    if (!permissionsList.isEmpty()) {
                        sender.addChatMessage(new ChatComponentText(groupName + " has the following permissions: " + permissionsList.toString()));
                    } else {
                        sender.addChatMessage(new ChatComponentText(groupName + " does not have any permissions."));
                    }
                }
            }
        }

        if (args.length == 5
                && (args[0].equals("user")
                || args[0].equals("group"))) {
            // The first arg is the group we are acting on [user/group]
            String type = args[0];

            // Check that group is valid
            if (!(type.equals("user")
                    || type.equals("group"))) {

                // Not a valid command group
                sender.addChatMessage(new ChatComponentText("Invalid command group. Please see help."));

            }
            if (type.equals("user")) {
                new CommandHandlerPermUsers(pm, sender, args);
            } else if (type.equals("group")) {
                new CommandHandlerPermGroups(pm, sender, args);

            }

        }
    }

    @Override
    public boolean canCommandSenderUse(ICommandSender sender) {
        return sender.canUseCommand(this.getRequiredPermissionLevel(), this.getName());
    }

}
