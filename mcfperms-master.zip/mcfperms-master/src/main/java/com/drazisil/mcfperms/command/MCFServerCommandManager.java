/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

/*
 * ++++++++++ IMPORTANT: PLEASE READ ++++++++++
 * This file contains copyrighted code from the following sources:
 * net.minecraft.command.ServerCommandManager.java
 * new.minecraft.command.CommandHandler.java
 *
 * Since it overrides/rewrites executeCommand from CommandHandler
 * it is required to recreate getUsernameIndex() and dropFirstString()
 * as these methods are private.
 *
 * This is the only file that contains copyrighted code, and it is my hope
 * that the owners of the Minecraft IP doe not have an issue with it.
 * I have tried my best to reuse as little code as possible.
 *
 */

package com.drazisil.mcfperms.command;

import com.drazisil.mcfperms.MCFPerms;
import com.drazisil.mcfperms.permissions.PermissionsManager;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import net.minecraft.command.*;
import net.minecraft.command.common.CommandReplaceItem;
import net.minecraft.command.server.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.UserListOpsEntry;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.EnumChatFormatting;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

public class MCFServerCommandManager extends CommandHandler implements IAdminCommand, ICommandManager
{
    private static final Logger logger = LogManager.getLogger(MCFPerms.MODID);
    /** Map of Strings to the ICommand objects they represent */
    private final Map commandMap = Maps.newHashMap();
    /** The set of ICommand objects currently loaded. */
    private final Set commandSet = Sets.newHashSet();
    private final Map commandPermissionsMap = Maps.newHashMap();
    /**
     * The set of ICommand objects currently loaded.
     */
    private final Set commandPermissionsSet = Sets.newHashSet();
    private final PermissionsManager permManager = new PermissionsManager();

    public MCFServerCommandManager() {

        this.registerCommand(new CommandTime(), "vanilla.time");
        this.registerCommand(new CommandGameMode(), "vanilla.gameMode");
        this.registerCommand(new CommandDifficulty(), "vanilla.difficulty");
        this.registerCommand(new CommandDefaultGameMode(), "vanilla.defaultGameMode");
        this.registerCommand(new CommandKill(), "vanilla.kill");
        this.registerCommand(new CommandToggleDownfall(), "vanilla.toggleDownfall");
        this.registerCommand(new CommandWeather(), "vanilla.weather");
        this.registerCommand(new CommandXP(), "vanilla.xp");
        this.registerCommand(new CommandTeleport(), "vanilla.teleport");
        this.registerCommand(new CommandGive(), "vanilla.give");
        this.registerCommand(new CommandReplaceItem(), "vanilla.replaceItem");
        this.registerCommand(new CommandStats(), "vanilla.stats");
        this.registerCommand(new CommandEffect(), "vanilla.effect");
        this.registerCommand(new CommandEnchant(), "vanilla.enchant");
        this.registerCommand(new CommandParticle(), "vanilla.particle");
        this.registerCommand(new CommandEmote(), "vanilla.emote");
        this.registerCommand(new CommandShowSeed(), "vanilla.seed");
        this.registerCommand(new CommandHelp(), "vanilla.help");
        this.registerCommand(new CommandDebug(), "vanilla.debug");
        this.registerCommand(new CommandMessage(), "vanilla.tell");
        this.registerCommand(new CommandBroadcast(), "vanilla.broadcast");
        this.registerCommand(new CommandSetSpawnpoint(), "vanilla.setSpawn");
        this.registerCommand(new CommandSetDefaultSpawnpoint(), "vanilla.defaultSpawn");
        this.registerCommand(new CommandGameRule(), "vanilla.gameRule");
        this.registerCommand(new CommandClearInventory(), "vanilla.clearInventory");
        this.registerCommand(new CommandTestFor(), "vanilla.testFor");
        this.registerCommand(new CommandSpreadPlayers(), "vanilla.spreadPlayers");
        this.registerCommand(new CommandPlaySound(), "vanilla.playSound");
        this.registerCommand(new CommandScoreboard(), "vanilla.scoreboard");
        this.registerCommand(new CommandExecuteAt(), "vanilla.executeAt");
        this.registerCommand(new CommandTrigger(), "vanilla.trigger");
        this.registerCommand(new CommandAchievement(), "vanilla.achievement");
        this.registerCommand(new CommandSummon(), "vanilla.summon");
        this.registerCommand(new CommandSetBlock(), "vanilla.setBlock");
        this.registerCommand(new CommandFill(), "vanilla.fill");
        this.registerCommand(new CommandClone(), "vanilla.clone");
        this.registerCommand(new CommandCompare(), "vanilla.compare");
        this.registerCommand(new CommandBlockData(), "vanilla.blackData");
        this.registerCommand(new CommandTestForBlock(), "vanilla.testFor");
        this.registerCommand(new CommandMessageRaw(), "vanilla.raw");
        this.registerCommand(new CommandWorldBorder(), "vanilla.worldBorder");
        this.registerCommand(new CommandTitle(), "vanilla.title");
        this.registerCommand(new CommandEntityData(), "vanilla.entityData");

        if (MinecraftServer.getServer().isDedicatedServer()) {
            this.registerCommand(new CommandOp(), "vanilla.op");
            this.registerCommand(new CommandDeOp(), "vanilla.deOp");
            this.registerCommand(new CommandStop(), "vanilla.stop");
            this.registerCommand(new CommandSaveAll(), "vanilla.saveAll");
            this.registerCommand(new CommandSaveOff(), "vanilla.saveOff");
            this.registerCommand(new CommandSaveOn(), "vanilla.saveOn");
            this.registerCommand(new CommandBanIp(), "vanilla.banIp");
            this.registerCommand(new CommandPardonIp(), "vanilla.pardonIp");
            this.registerCommand(new CommandBanPlayer(), "vanilla.banPlayer");
            this.registerCommand(new CommandListBans(), "vanilla.listBans");
            this.registerCommand(new CommandPardonPlayer(), "vanilla.pardon");
            this.registerCommand(new CommandServerKick(), "vanilla.kick");
            this.registerCommand(new CommandListPlayers(), "vanilla.listPlayers");
            this.registerCommand(new CommandWhitelist(), "vanilla.whiteList");
            this.registerCommand(new CommandSetPlayerTimeout(), "vanilla.timeout");
        }
        else
        {
            this.registerCommand(new CommandPublishLocalServer());
        }

        CommandBase.setAdminCommander(this);
    }

    /**
     * creates a new array and sets elements 0..n-2 to be 0..n-1 of the input (n elements)
     */
    private static String[] dropFirstString(String[] input) {
        String[] s = new String[input.length - 1];
        System.arraycopy(input, 1, s, 0, input.length - 1);
        return s;
    }

    @Override
    public void notifyOperators(ICommandSender sender, ICommand command, int p_152372_3_, String msgFormat, Object ... msgParams)
    {
        // Use ServerCommandManager.notifyOperators()
        ServerCommandManager tmpMgr = new ServerCommandManager();
        tmpMgr.notifyOperators(sender, command, p_152372_3_, msgFormat, msgParams);
    }

    /**
     * Executes command
     *
     * @param sender     ICommandSender
     * @param rawCommand String
     * @return int
     */
    @Override
    public int executeCommand(ICommandSender sender, String rawCommand) {
        /*
         Log the command
          */
        logger.info(sender.getName() + " issued " + rawCommand);

        rawCommand = rawCommand.trim();

        if (rawCommand.startsWith("/"))
        {
            rawCommand = rawCommand.substring(1);
        }

        String[] aString = rawCommand.split(" ");
        String s1 = aString[0];
        aString = dropFirstString(aString);
        ICommand icommand = (ICommand)this.commandMap.get(s1);
        String iCommandPerm = (String) this.commandPermissionsMap.get(s1);
        int i = this.getUsernameIndex(icommand, aString);
        int j = 0;
        ChatComponentTranslation chatcomponenttranslation;

        if (icommand == null)
        {
            chatcomponenttranslation = new ChatComponentTranslation("commands.generic.notFound");
            chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.RED);
            sender.addChatMessage(chatcomponenttranslation);
        } else if (checkCommandPermission(sender, icommand, iCommandPerm)) {
            net.minecraftforge.event.CommandEvent event = new net.minecraftforge.event.CommandEvent(icommand, sender, aString);
            if (net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(event))
            {
                if (event.exception != null)
                {
                    com.google.common.base.Throwables.propagateIfPossible(event.exception);
                }
                return 1;
            }

            if (i > -1) {
                List list = PlayerSelector.matchEntities(sender, aString[i], Entity.class);
                String s2 = aString[i];
                sender.setCommandStat(CommandResultStats.Type.AFFECTED_ENTITIES, list.size());

                for (Object aList : list) {
                    Entity entity = (Entity) aList;
                    aString[i] = entity.getUniqueID().toString();

                    if (this.tryExecute(sender, aString, icommand, rawCommand)) {
                        ++j;
                    }
                }

                aString[i] = s2;
            }
            else
            {
                sender.setCommandStat(CommandResultStats.Type.AFFECTED_ENTITIES, 1);

                if (this.tryExecute(sender, aString, icommand, rawCommand))
                {
                    ++j;
                }
            }
        }
        else
        {
            chatcomponenttranslation = new ChatComponentTranslation("commands.generic.permission");
            chatcomponenttranslation.getChatStyle().setColor(EnumChatFormatting.RED);
            sender.addChatMessage(chatcomponenttranslation);
        }

        sender.setCommandStat(CommandResultStats.Type.SUCCESS_COUNT, j);
        return j;
    }

    /**
     * Check if sender has the permission to use command
     * @param sender ICommandSender
     * @param command ICommand
     * @return boolean
     */
    private boolean checkCommandPermission(ICommandSender sender, ICommand command, String permission){
        if (sender instanceof EntityPlayerMP) {
            EntityPlayerMP player = (EntityPlayerMP) sender;
            /*
            Check if player can use command
             */
            if (permManager.checkPlayerPermissionForCommand(sender.getName(), permission)) {
                /*
                Player is allowed the use command
                 */
                logger.debug("Permission check for permission (" + permission + ") on player (" + sender.getName() + ") passed.");
                return true;
            } else {
                /*
                Is use fall-though configured? If so, check if the command itself allows use for sender
                 */
                if (MCFPerms.proxy.isUsePermissionDefaultsFallthrough()) {
                    logger.debug("Permission check for permission (" + permission + ") on player (" + sender.getName() + ") failed, testing with vanilla.");
                    if (player.mcServer.getConfigurationManager().canSendCommands(player.getGameProfile())) {
                        // This checks if the sender is an op
                        int permLevel = ((CommandBase) command).getRequiredPermissionLevel();
                        UserListOpsEntry userlistopsentry = (UserListOpsEntry) player.mcServer.getConfigurationManager().getOppedPlayers().getEntry(player.getGameProfile());
                        return userlistopsentry != null ? userlistopsentry.getPermissionLevel() >= permLevel : player.mcServer.getOpPermissionLevel() >= permLevel;
                    }

                    return command.canCommandSenderUse(sender);

                } else {
                    /*
                     permission check failed, and not allowed to use vanilla defaults
                      */
                    logger.debug("Permission check for permission (" + permission + ") on player (" + sender.getName() + ") failed.");
                    return false;
                }
            }
        } else {
            return command.canCommandSenderUse(sender);
        }
    }

    /**
     * vanilla call, used when a permission node is not passed by mods that
     * don't pass a permission node.
     *
     */
    @Override
    public ICommand registerCommand(ICommand command) {
        return registerCommand(command, command.getClass().getName());
    }

    /**
     * adds the command and any aliases it has to the internal map of available commands
     */
    public ICommand registerCommand(ICommand command, String permission)
    {
        this.commandMap.put(command.getName(), command);
        this.commandSet.add(command);
        this.commandPermissionsMap.put(command.getName(), permission);
        this.commandPermissionsSet.add(permission);

        for (Object o : command.getAliases()) {
            String s = (String) o;
            ICommand iCommand = (ICommand) this.commandMap.get(s);

            if (iCommand == null || !iCommand.getName().equals(s)) {
                this.commandMap.put(s, command);
                this.commandSet.add(iCommand);
                this.commandPermissionsMap.put(s, permission);
            }
        }
        logger.info("Registered " + command.getName() + " with permission node " + permission);

        return command;
    }

    /**
     * Return a commands first parameter index containing a valid username.
     */
    private int getUsernameIndex(ICommand command, String[] args)
    {
        if (command == null)
        {
            return -1;
        }
        else
        {
            for (int i = 0; i < args.length; ++i)
            {
                if (command.isUsernameIndex(args, i) && PlayerSelector.matchesMultiplePlayers(args[i]))
                {
                    return i;
                }
            }

            return -1;
        }
    }

    /**
     * Gets a list of tab-autocomplete options
     * @param sender ICommandSender
     * @param input String
     * @param pos BlockPos
     * @return List
     */
    public List getTabCompletionOptions(ICommandSender sender, String input, BlockPos pos) {
        String[] s = input.split(" ", -1);
        String s1 = s[0];

        permManager.init();

        if (s.length == 1) {
            ArrayList arraylist = Lists.newArrayList();

            for (Object o : this.commandMap.entrySet()) {
                Map.Entry entry = (Map.Entry) o;

                if (CommandBase.doesStringStartWith(s1, (String) entry.getKey()) && ((ICommand) entry.getValue()).canCommandSenderUse(sender)) {
                    arraylist.add(entry.getKey());
                }
            }

            return arraylist;
        } else {
            if (s.length > 1) {
                ICommand icommand = (ICommand) this.commandMap.get(s1);

                if (icommand != null && (permManager.checkUserPermission(sender.getName(), (String) this.commandPermissionsMap.get(icommand.getName())) || icommand.canCommandSenderUse(sender))) {
                    return icommand.addTabCompletionOptions(sender, dropFirstString(s), pos);
                }
            }

            return null;
        }
    }

    /**
     * returns all commands that the commandSender can use
     */
    public List getPossibleCommands(ICommandSender sender) {
        ArrayList arraylist = Lists.newArrayList();
        Iterator iterator = this.commandSet.iterator();

        permManager.init();

        while (iterator.hasNext()) {
            ICommand icommand = (ICommand) iterator.next();

            if (icommand != null) {
                if (permManager.checkUserPermission(sender.getName(), (String) this.commandPermissionsMap.get(icommand.getName()))) {
                    arraylist.add(icommand);
                } else {
                    if (icommand.canCommandSenderUse(sender)) {
                        arraylist.add(icommand);
                    }
                }

            }
        }

        return arraylist;
    }

    /**
     * returns a map of string to commands. All commands are returned, not just ones which someone has permission to use.
     */
    public Map getCommands() {
        return this.commandMap;
    }


}
