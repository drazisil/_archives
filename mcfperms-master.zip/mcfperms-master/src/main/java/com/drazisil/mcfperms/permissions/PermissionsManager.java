/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfperms.permissions;

import com.drazisil.mcfperms.MCFPerms;
import com.drazisil.mcfperms.util.YamlHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PermissionsManager {

    private static final Logger logger = LogManager.getLogger(MCFPerms.MODID);

    // Get the permissions handler
    private YamlHandler p;

    public PermissionsManager() {
        p = MCFPerms.proxy.getYamlPermissions();
    }

    /**
     * Public method call for #checkPermission() for type users
     * This is called by com.drazisil.mcfperms.MCFServerCommandManager#checkCommandPermission()
     *
     * @param playerName     String
     * @param permissionNode String
     * @return boolean
     */
    public boolean checkPlayerPermissionForCommand(String playerName, String permissionNode) {

        return checkPermission("users", playerName.toLowerCase(), permissionNode.toLowerCase(), true);

    }

    /**
     * Public method call for #addPermission() for type users
     *
     * @param player         String
     * @param permissionNode String
     * @return boolean
     */
    public boolean addUserPermission(String player, String permissionNode) {
        return addPermissions("users", player.toLowerCase(), permissionNode.toLowerCase());
    }


    /**
     * Public method call for #addPermission() for type groups
     *
     * @param player         String
     * @param permissionNode String
     * @return boolean
     */
    public boolean addGroupPermission(String player, String permissionNode) {
        return addPermissions("groups", player.toLowerCase(), permissionNode.toLowerCase());
    }

    /**
     * Add a permission entry of permissionNode to either the user or groups section of the permissions file
     *
     * @param type           String
     * @param name           String
     * @param permissionNode String
     * @return boolean
     */
    private boolean addPermissions(String type, String name, String permissionNode) {
        if (!type.equals("groups") && !type.equals("users")) {
            logger.error("Unknown type, unable to check permissions of type: " + type);
            return false;
        }

        name = name.toLowerCase();

        // Check if this is a player and make sure they exist first
        if (type.equals("users")) {
            // Check if there is a record for player
            createPlayerIfNotExists(name);
        }
        // Check if this is a group and make sure it exists first
        if (type.equals("groups")) {
            // Check if there is a record for player
            createGroupIfNotExists(name.toLowerCase());

        }
        HashMap playerSection = p.getSubSection(type, name.toLowerCase());
        List<String> groups = p.getSubSectionList(playerSection, "permissions");
        if (groups.add(permissionNode.toLowerCase())) {
            p.save();
            return true;

        }
        return false;
    }

    /**
     * Make a user a member of a group
     *
     * @param name      String
     * @param groupName String
     * @return boolean
     */
    public boolean addGroup(String name, String groupName) {
        /*
        Create user if they don't exist
         */
        createPlayerIfNotExists(name.toLowerCase());

        // Check if this is a group and make sure they exist first
        createPlayerIfNotExists(name.toLowerCase());

        HashMap playerSection = p.getSubSection("users", name);
        List<String> groups = p.getSubSectionList(playerSection, "groups");
        if (groups.add(groupName.toLowerCase())) {
            p.save();
            return true;

        }
        return false;

    }

    /**
     * Check if a player exists, and create in the permissions file if they do not
     *
     * @param playerName String
     */
    private void createPlayerIfNotExists(String playerName) {
        if (!p.checkSubSection("users", playerName.toLowerCase())) {
            createUser(playerName.toLowerCase());
        }
    }

    private void createGroupIfNotExists(String groupName) {
        if (!p.checkSubSection("groups", groupName.toLowerCase())) {
            createGroup(groupName.toLowerCase());
        }
    }

    /**
     * Call to #removePermissions() with type users
     *
     * @param userName       String
     * @param permissionNode String
     * @return boolean
     */
    public boolean removeUserPermission(String userName, String permissionNode) {
        return removePermissions("users", userName.toLowerCase(), permissionNode.toLowerCase());
    }

    /**
     * Call to #removePermissions() with type groups
     *
     * @param groupName      String
     * @param permissionNode String
     * @return boolean
     */
    public boolean removeGroupPermission(String groupName, String permissionNode) {
        return removePermissions("groups", groupName.toLowerCase(), permissionNode.toLowerCase());
    }

    /**
     * Remove a permission from a user or group
     *
     * @param type           String
     * @param name           String
     * @param permissionNode String
     * @return boolean
     */
    private boolean removePermissions(String type, String name, String permissionNode) {
        if (!type.equals("groups") && !type.equals("users")) {
            logger.error("Unknown type, unable to check permissions of type: " + type);
            return false;
        }
        // Check if this is a player and make sure they exist first
        if (type.equals("users")) {
            // Check if there is a record for player
            if (!playerExists(name.toLowerCase())) {
                logger.info(name + " does not exist.");
                return false;
            }

        }
        // Check if this is a group and make sure it exists first
        if (type.equals("groups")) {
            // Check if there is a record for player
            if (!groupExists(name.toLowerCase())) {
                logger.info(name + " does not exist.");
                return false;
            }

        }
        HashMap playerSection = p.getSubSection(type, name.toLowerCase());
        List<String> groups = p.getSubSectionList(playerSection, "permissions");
        if (groups.remove(permissionNode.toLowerCase())) {
            p.save();
            return true;

        }
        return false;
    }

    /**
     * Remove a user as a member of a group
     *
     * @param userName  String
     * @param groupName String
     * @return boolean
     */
    public boolean removeGroup(String userName, String groupName) {
        // Check if this is a player and make sure they exist first
        if (playerExists(userName.toLowerCase())) {

            HashMap playerSection = p.getSubSection("users", userName.toLowerCase());
            List<String> groups = p.getSubSectionList(playerSection, "groups");
            if (groups.remove(groupName.toLowerCase())) {
                p.save();
                return true;

            }
        } else {
            logger.info(userName + " does not exist.");
            return false;
        }
        return false;
    }

    /**
     * Call to #checkPermission() with type users
     *
     * @param userName       String
     * @param permissionNode String
     * @return boolean
     */
    public boolean checkUserPermission(String userName, String permissionNode) {
        return checkPermission("users", userName, permissionNode.toLowerCase(), false);
    }

    /**
     * Call to #checkPermission() with type groups
     *
     * @param groupName      String
     * @param permissionNode String
     * @return boolean
     */
    public boolean checkGroupPermission(String groupName, String permissionNode) {
        return checkPermission("groups", groupName, permissionNode.toLowerCase(), false);
    }

    /**
     * Check if a user or group has the requested permission
     *
     * @param type           String
     * @param name           String
     * @param permissionNode String
     * @param recursive      boolean
     * @return boolean
     */
    private boolean checkPermission(String type, String name, String permissionNode, Boolean recursive) {

        p = MCFPerms.proxy.getYamlPermissions();

        /*
        Is this a valid type?
         */
        if (!type.equals("groups") && !type.equals("users")) {
            logger.error("Unknown type, unable to check permissions of type: " + type);
            return false;
        }

        /*
        Create player if this is a user and they don't exist yet
        */
        if (type.equals("users")) {
            // Check if there is a record for player
            createPlayerIfNotExists(name);
/*
            if (!playerExists(name)) {
                logger.info(name + " does not exist.");
                createUser(name);
                return false;
            }
*/
        }

        /*
         Check if this is a group and make sure they exist first
          */
        if (type.equals("groups")) {
            createGroupIfNotExists(name);
        }

        /*
        Get list of names permissions
         */
        if (p.checkSubSection(type, name.toLowerCase())) {
            HashMap subSection = p.getSubSection(p.getSection(type), name.toLowerCase());
            List<String> playerPermissions = p.getSubSectionValues(subSection, "permissions");
            logger.debug("Checked " + name + "'s permissions with " + playerPermissions.size() + " permissions for " + permissionNode);
            if (isValueMemberOfList(playerPermissions, permissionNode)) {
                /*
                This group or user can use this permission directly
                 */
                logger.debug(name + " has permission to use " + permissionNode);
                return true;
            } else {
                /*
                If we don't want to check further, return here
                 */
                if (!recursive) {
                    return false;
                }

                /*
                Is name a member of any groups that grant permission?
                 */
                ArrayList<String> groups = getUserGroups(name);
                for (String i : groups) {
                    if (checkGroupPermission(i, permissionNode)) {
                        logger.debug(name + " is granted " + permissionNode + " via the " + i + " group.");
                        return true;
                    }
                }

                /*
                It appears name neither has access to permission directly, nor is a member of any groups that grant it.
                return false;
                 */
                return false;

            }
        } else {
            // Default section not found, this is a problem
            logger.error("permissions unable to be read for " + name + ".");
            return false;
        }
    }

    /**
     * Check if a user is a member of a group
     *
     * @param name      String
     * @param groupName String
     * @return boolean
     */
    public boolean checkGroup(String name, String groupName) {
        // Check if this is a player and make sure they exist first
        if (playerExists(name)) {
            if (p.checkSubSection("users", name)) {
                HashMap subSection = p.getSubSection(p.getSection("users"), name.toLowerCase());
                List<String> groups = p.getSubSectionValues(subSection, "groups");
                logger.debug("Checked " + name + " permissions with " + groups.size() + " permissions for " + groupName);
                if (isValueMemberOfList(groups, groupName)) {
                    logger.debug(name + " is a member of " + groupName);
                    return true;
                } else {
                    logger.debug(name + " is NOT a member of " + groupName);
                    return false;
                }
            } else {
                logger.debug(name + " does not exist.");
                return false;
            }

        }
        return false;
    }


    /**
     * Call to #getPermissions() for type users
     *
     * @param userName String
     * @return List<String>
     */
    public ArrayList<String> getUserPermissions(String userName) {
        return getPermissions("users", userName.toLowerCase());
    }

    /**
     * Call to #getPermissions() for type groups
     *
     * @param groupName String
     * @return List<String>
     */
    public ArrayList<String> getGroupPermissions(String groupName) {
        return getPermissions("groups", groupName.toLowerCase());
    }

    /**
     * Get a list of permissions for a user or group
     *
     * @param type String
     * @param name String
     * @return boolean
     */
    private ArrayList<String> getPermissions(String type, String name) {
        HashMap section = p.getSubSection(type, name.toLowerCase());
        return (ArrayList<String>) p.getSubSectionList(section, "permissions");

    }

    /**
     * Create the default permission.yml file
     *
     * @param filePermissions String
     */
    public void createDefaultPermissions(String filePermissions) {
        try {
            FileWriter filePermissionsWriter = new FileWriter(filePermissions);
            filePermissionsWriter.write(
                    "users: {}\n" +
                            "groups:\n" +
                            "  default:\n" +
                            "    options:\n" +
                            "      default: true\n" +
                            "    permissions:\n" +
                            "    - vanilla.emote\n" +
                            "    - vanilla.help\n" +
                            "    - vanilla.tell\n" +
                            "    - vanilla.trigger");
            filePermissionsWriter.close();
        } catch (IOException e) {
            logger.error("Unable to open file " + filePermissions + " for writing");
        }

    }

    /**
     * Create a new user in the permissions file
     *
     * @param userName String
     */
    private void createUser(String userName) {
        logger.debug("Trying to create " + userName);
        p.addSubSection("users", userName);
        HashMap playerSection = p.getSubSection("users", userName.toLowerCase());
        p.addSubSectionList(playerSection, "groups");
        p.addSubSectionList(playerSection, "permissions");
        List<String> groups = p.getSubSectionList(playerSection, "groups");
        groups.add("default");

        p.save();
    }

    /**
     * Create a new group in the permissions file
     *
     * @param groupName String
     */
    private void createGroup(String groupName) {
        logger.debug("Trying to create " + groupName);
        p.addSubSection("groups", groupName);
        HashMap playerSection = p.getSubSection("groups", groupName.toLowerCase());
            p.addSubSectionList(playerSection, "permissions");
            p.addSubSectionList(playerSection, "options");
            p.save();
    }


    /**
     * Check if a player exists in the permissions file
     *
     * @param playerName String
     * @return boolean
     */
    private boolean playerExists(String playerName) {
        return p.checkSubSection("users", playerName.toLowerCase());
    }

    /**
     * Check if a group exists in the permissions file
     *
     * @param groupName String
     * @return boolean
     */
    private boolean groupExists(String groupName) {
        return p.checkSubSection("groups", groupName.toLowerCase());
    }

    /**
     * Check if value is in list
     *
     * @param group List
     * @param value String
     * @return boolean
     */
    private boolean isValueMemberOfList(List group, String value) {
        return !group.isEmpty() && group.contains(value.toLowerCase());
    }

    public void init() {
        p = MCFPerms.proxy.getYamlPermissions();
    }


    /**
     * Get list of group a user is a member of
     *
     * @param name String
     * @return List<String>
     */
    public ArrayList<String> getUserGroups(String name) {
        HashMap section = p.getSubSection("users", name.toLowerCase());
        return (ArrayList<String>) p.getSubSectionList(section, "groups");

    }

    /**
     * Get list of all users in the permissions file
     *
     * @return List<String>
     */
    public ArrayList<String> getUserList() {
        HashMap section = p.getSection("users");
        return new ArrayList<String>(section.keySet());
    }

    /**
     * Get list of all groups in the permission file
     *
     * @return List<String>
     */
    public ArrayList<String> getGroupList() {
        HashMap section = p.getSection("groups");
        return new ArrayList<String>(section.keySet());
    }
}
