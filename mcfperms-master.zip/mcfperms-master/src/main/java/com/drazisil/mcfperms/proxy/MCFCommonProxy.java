/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfperms.proxy;

import com.drazisil.mcfperms.MCFPerms;
import com.drazisil.mcfperms.command.CommandMCFPerms;
import com.drazisil.mcfperms.command.MCFServerCommandManager;
import com.drazisil.mcfperms.permissions.PermissionsManager;
import com.drazisil.mcfperms.util.YamlHandler;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

public class MCFCommonProxy {
    private static final Logger logger = LogManager.getLogger(MCFPerms.MODID);

    private YamlHandler yamlPermissions;
    private boolean usePermissionDefaultsFallthrough = false;

    public YamlHandler getYamlPermissions() {
        return yamlPermissions;
    }

    @SuppressWarnings("SameReturnValue")
    public boolean isClient() {
        return false;
    }

    public void preInit(FMLPreInitializationEvent event) {
        // Swap out the ServerCommand Manager
        redirectCommandManager();

        // Not currently using events at the global level, but leaving the code for reference
        //FMLCommonHandler.instance().bus().register(events);
        //MinecraftForge.EVENT_BUS.register(events);

        // Get the configuration
        Configuration config = new Configuration(event.getSuggestedConfigurationFile());

        // Get the configuration path
        File configPath = event.getModConfigurationDirectory();
        logger.info(configPath.toString());

        config.load();
        usePermissionDefaultsFallthrough = config.get("general", "defaultsFallthrough", true).getBoolean(true);

        config.save();

        String permissionsFile = configPath.toString() + "/permissions.yml";

        yamlPermissions = new YamlHandler(permissionsFile);
        if (yamlPermissions.load()) {
            Integer numEntries = yamlPermissions.getRootCount();
            logger.info("Permissions config file loaded with " + numEntries + " entries.");
            if (numEntries <= 0) {
                // file is empty, set defaults
                logger.info("Creating default permissions file.");
                PermissionsManager permManager = new PermissionsManager();
                permManager.createDefaultPermissions(permissionsFile);
                yamlPermissions.load();
            }
        } else {
            logger.fatal("Unable to load permissions file.");
        }


    }

    public void serverLoad(FMLServerStartingEvent event) {

        MCFServerCommandManager ch = (MCFServerCommandManager) event.getServer().getCommandManager();
        ch.registerCommand(new CommandMCFPerms(), "mcfperms.perm");
    }

    /**
     * Uses reflection to switch the value of MinecraftServer.commandManager
     * to MCFServerCommandManager
     */
    @SuppressWarnings("WeakerAccess")
    protected void redirectCommandManager() {

        //String serverType = MinecraftServer.getServer().getClass().getName();
        ObfuscationReflectionHelper.setPrivateValue(MinecraftServer.class,
                MinecraftServer.getServer(), new MCFServerCommandManager(),
                "commandManager", "field_71321_q");
    }


    public boolean isUsePermissionDefaultsFallthrough() {
        return usePermissionDefaultsFallthrough;
    }

}