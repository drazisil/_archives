/*
 * Copyright 2015 Joseph W Becher <jwbecher@drazisil.com>
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package com.drazisil.mcfperms.util;

import com.drazisil.mcfperms.MCFPerms;
import com.esotericsoftware.yamlbeans.YamlException;
import com.esotericsoftware.yamlbeans.YamlReader;
import com.esotericsoftware.yamlbeans.YamlWriter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class YamlHandler {
    private static final Logger logger = LogManager.getLogger(MCFPerms.MODID);

    private File fileConfig = null;

    private HashMap<String, HashMap> rootObj = null;

    public YamlHandler(String configFile) {
        fileConfig = new File(configFile);
        createIfNotExists();
    }

    private void createIfNotExists() {
        if (!fileConfig.exists()) {
            try {
                if (fileConfig.createNewFile()) {
                    logger.info("New config file " + fileConfig.getName() + " created.");
                } else {
                    logger.error("New config file " + fileConfig.getName() + " unable to be created.");
                }
            } catch (IOException e) {
                logger.error("Unable to create config file: " + e.getMessage());
            }
        }
    }


    public boolean load() {

        try {
            YamlReader reader = new YamlReader(new FileReader(fileConfig));
            try {
                rootObj = (HashMap<String, HashMap>) reader.read();
            } catch (YamlException e) {
                // Unable to read document
                logger.error("Error reading file: " + e.getMessage());
                return false;
            }
            return true;
        } catch (FileNotFoundException e) {
            // not able to load
            logger.error("File not found: " + e.getMessage());
            return false;
        }

    }

    public void save() {
        try {
            YamlWriter writer = new YamlWriter(new FileWriter(fileConfig));
            writer.write(rootObj);
            writer.close();
            logger.info("Config file " + fileConfig.getName() + " saved.");
        } catch (IOException e) {
            logger.error("Unable to open file " + fileConfig.getName() + " for writing..");
        }
    }

    public Integer getRootCount() {
        if (rootObj == null) {
            return 0;
        } else {
            return rootObj.size();
        }
    }

    public boolean checkSubSection(String section, String subSection) {
        return !rootObj.isEmpty() && rootObj.containsKey(section) && rootObj.get(section).containsKey(subSection);
    }

    public void addSubSection(String section, String subSection) {
        if (!rootObj.isEmpty() && !rootObj.get(section).containsKey(subSection)) {
            rootObj.get(section).put(subSection, new HashMap<String, HashMap>());
        }
    }

    public void addSubSectionList(HashMap section, String subSection) {
        if (!rootObj.isEmpty() && !section.containsKey(subSection)) {
            section.put(subSection, new ArrayList<String>());
        }
    }

    public HashMap getSection(String section) {
        if (!rootObj.isEmpty() && rootObj.containsKey(section)) {
            return rootObj.get(section);
        }
        return null;
    }

    public HashMap getSubSection(HashMap section, String subSection) {
        if (!section.isEmpty() && section.containsKey(subSection)) {
            return (HashMap) section.get(subSection);
        }
        return null;
    }

    public List<String> getSubSectionList(HashMap section, String subSection) {
        if (!section.isEmpty() && section.containsKey(subSection)) {
            return (List<String>) section.get(subSection);
        }
        return null;
    }

    public HashMap getSubSection(String section, String subSection) {
        if (!section.isEmpty() && rootObj.get(section).containsKey(subSection)) {
            return (HashMap) rootObj.get(section).get(subSection);
        }
        return null;
    }

    public List<String> getSubSectionValues(HashMap section, String subsection) {
        if (!section.isEmpty()) {
            return new ArrayList<String>((Collection<? extends String>) section.get(subsection));
        }
        return null;
    }


}
