package com.drazisil.mineblocker;

/**
 * Created by joseph on 9/13/2014.
 */
public class MineblockerGame {
    public MineblockerGame(Object args) {
    }

    public void Run() {
    }
}
