npcblocker
==========

A World of Warcraft addon to block npcs
