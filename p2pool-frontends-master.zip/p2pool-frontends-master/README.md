P2PoolExtendFrontEnd
====================

Extended front end web interface for p2pool

How install
====================
In your p2pool folder:
* rm -R web-static
* git clone https://github.com/drazisil/P2PoolExtendedFrontEnd.git web-static

Configuring Price lookup:
-------------------------
This version uses BitPay's API to display payouts in your local currency.
It comes with USD and EUR, if you would like to add more you can do so to the table at the bottom of graphs.html.

Donations towards further development:
-------------------------
    drazisil: 1CMmcUre9Nhs2ndinA1MDfdhxsSN4Eracq

Credits:
-------------------------
* original design from https://github.com/hardcpp/P2PoolExtendedFrontEnd
