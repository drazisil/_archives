[![Build Status](https://travis-ci.org/drazisil/p2pools.blocksplorer.com.svg?branch=master)](https://travis-ci.org/drazisil/p2pools.blocksplorer.com)

# p2pools.blocksplorer.com

common/run_addr_parse.py loops and parses the p2pool addrs file into a sqlite database
