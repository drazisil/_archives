import httplib, io, json, time, socket, sqlite3, urllib2

import config

# table design
table_name = 'peers'  # name of the table to be created
host_column = 'host'
port_column = 'port'
hashrate_column = 'node_hashrate'
last_seen_column = 'last_seen'
uptime_column = 'uptime'
int_type = 'INTEGER'  # column data type
txt_type = 'TEXT'  # column data type
real_type = 'REAL'  # column data type

# Testing sqllite
conn = sqlite3.connect('peers.db')

try:
    # Creating a new SQLite table with 1 column
    conn.execute('CREATE TABLE IF NOT EXISTS {tn} ({cn1} {ct2} UNIQUE, {cn2} {ct2}, {cn3} {ct3}, \
    {cn4} {ct4}, {cn5} {ct5})'\
        .format(tn=table_name, cn1=host_column, ct1=txt_type, cn2=port_column, ct2=int_type, \
            cn3=hashrate_column, ct3=real_type, cn4=last_seen_column, ct4=real_type, \
                cn5=uptime_column, ct5=real_type))
except sqlite3.Error as e:
    z = e
        
# close the database
conn.commit()

def testNode(host, test=0):
    global conn
    
    good_node = 0
    try:
        req = urllib2.Request('http://' + host['host'] + ':9332/local_stats')
        f = urllib2.urlopen(req, timeout=1)
        addr_stats = json.loads(f.read())
        good_node = 1
    except urllib2.URLError as e:
        z = e
    except socket.error as e:
        z = e
    except httplib.BadStatusLine as e:
        z = e
    
    if good_node == 1:
        miner_count = len(addr_stats['miner_hash_rates'])
        total_hash = 0

        if miner_count > 0:
            for miner in addr_stats['miner_hash_rates'].values():
                total_hash = total_hash + miner

        current_node = {
            'host' : host['host'],
            'port' : host['port'],
            'last_seen' : int(time.time()),
            'node_hashrate' : total_hash,
            'uptime' : addr_stats['uptime']
        }

        if test == 1:
            return current_node
            exit()


        # B) Tries to insert an ID (if it does not exist yet)
        # with a specific value in a second column 
        conn.execute("INSERT OR IGNORE INTO {tn} ('host', 'port', 'node_hashrate', 'last_seen', 'uptime')\
        VALUES ('{v_host}', {v_port}, {v_hashrate}, {v_last_seen}, {v_uptime})".\
            format(tn='peers', v_host=current_node['host'], v_port=current_node['port'], \
                v_hashrate=current_node['node_hashrate'], v_last_seen=current_node['last_seen'], \
                v_uptime=current_node['uptime']))
        conn.commit()
        conn.execute("UPDATE OR IGNORE {tn} SET 'port' = {v_port}, 'node_hashrate' = {v_hashrate}, \
                'last_seen' = {v_last_seen}, 'uptime' = {v_uptime} WHERE 'host' = '{v_host}'".\
            format(tn='peers', v_host=current_node['host'], v_port=current_node['port'], \
                v_hashrate=current_node['node_hashrate'], v_last_seen=current_node['last_seen'], \
                v_uptime=current_node['uptime']))

        conn.commit()
        good_node = 0
        f.close()
    
    else:
        y = 0
        #print 'Node has no active miners'
            
def end():
    global conn, start_time, table_name
        
    #final

    # 1) Contents of all columns for row that match a certain value in 1 column
    c = conn.cursor()
    c.execute('SELECT * FROM {tn}'.\
        format(tn=table_name))
    all_rows = c.fetchall()
    for a in all_rows:
        print('Record):', a)
    conn.close()

    print("--- %s seconds ---" % (time.time() - start_time))
    exit()

def parseAddrs(addrs):
    for a in addrs:
        total_hash = 0
        host = a[0]
        #print host
        addr = {'host' : host[0], 'port' : host[1]}
        #print addr
        testNode(addr)
    parseAddrs(addrs)

def run():
    global config, start_time

    start_time = time.time()

    addrs = json.load(config.addrs_path)

    parseAddrs(addrs)
