import io

addrs_path = io.FileIO("/home/drazisil/p2pool/data/bitcoin/addrs")
