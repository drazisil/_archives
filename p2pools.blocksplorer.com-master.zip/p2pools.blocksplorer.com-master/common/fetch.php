<?php
error_reporting(E_ALL & ~E_NOTICE);
ini_set("display_errors", 1);

try{     
    $pdo = new PDO('sqlite:peers.db');
}catch (PDOException $e){
     die ('DB Error');
}

$sql = "SELECT * FROM peers ORDER BY last_seen DESC";
$res = $pdo->query($sql)->fetchAll();
header('content-type: application/json');
echo json_encode($res);
?>
