from nose.tools import assert_equal, assert_not_equal
import addrs_parse

import inspect

def test_testNode():
    addr = {}
    addr = {'host' : 'blocksplorer.com', 'port' : 9332}
    #print(inspect.getmembers(addrs_parse))
    assert_not_equal(addrs_parse.testNode(addr, 1), "")
