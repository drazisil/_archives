petguard
========

a bukkit plug to manage pets, protect against damage, and allow for transport
