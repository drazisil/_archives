/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jwebnet.petguard;

import org.bukkit.plugin.java.JavaPlugin;

public final class PetGuard extends JavaPlugin {

    /**
     *
     */
    @Override
    public void onEnable() {
        getLogger().info("onEnable has been invoked!");
                new PetGuardListener(this);
    }

    /**
     *
     */
    @Override
    public void onDisable() {
        getLogger().info("onDisable has been invoked!");
    }

  }

