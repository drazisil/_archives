/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jwebnet.petguard;

import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 *
 * @author joseph
 */
public final class PetGuardListener implements Listener {

    /**
     *
     * @param plugin
     */
    public PetGuardListener(PetGuard plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    /**
     *
     * @param event
     */
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {

        if (event.getEntity() instanceof LivingEntity) {

            /*
             The entity taking the damage
             */
            Entity damagee;
            damagee = event.getEntity();

            /*
             the type of entity the damagee is
             */
            EntityType damageeType;
            damageeType = damagee.getType();

            /*
             The ID of the damagee
             */
            UUID uuid;
            uuid = damagee.getUniqueId();

            /*
             The location damage occurs
             */
            Location location;
            location = damagee.getLocation();

            /*
             The world name where the damagee is
             */
            String worldName;
            worldName = location.getWorld().getName();

            /*
             http://jd.bukkit.org/beta/apidocs/org/bukkit/event/entity/EntityDamageEvent.DamageCause.html
             Damage cause types to check for:
             * BLOCK_EXPLOSION
             * CONTACT
             * CUSTOM
             * DROWNING
             * ENTITY_ATTACK
             * ENTITY_EXPLOSION
             * FALL
             * FALLING_BLOCK
             * FIRE
             * FIRE_TICK
             * LAVA
             * LIGHTNING
             * MAGIC
             * MELTING
             * POISON
             * PROJECTILE
             * STARVATION
             * SUFFOCATION
             * SUICIDE
             * THORNS
             * VOID
             * WITHER
             */
            EntityDamageEvent.DamageCause cause;
            cause = event.getCause();
            Bukkit.broadcastMessage(worldName + " Ouch: " + damageeType.name() + " by " + cause.name());

        }

    }

}
