Icon credit: "Silk" v1.3 - http://www.famfamfam.com/lab/icons/silk/
Favicon credit: http://icongal.com/gallery/icon/88989/128/write_doc_file_document_paper_list_list_of_bills

