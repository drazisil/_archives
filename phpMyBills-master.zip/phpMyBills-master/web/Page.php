<?php

switch ($pageName) {
    case 'Index':
        require_once 'pages/index_settings.php';
        require_once 'pages/index.php';

        break;
    case 'Login':
        require_once 'pages/login_settings.php';
        require_once 'pages/login.php';

        break;
    case 'Register':
        require_once 'pages/register_settings.php';
        require_once 'pages/register.php';

        break;

    default:
        break;
}

?>
