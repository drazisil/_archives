<?php

/**
 * Main application handler
 */
/*
 * Set the eroor reporting to debug
 */
error_reporting(E_ALL | E_STRICT);

/*
 * Is there a config file?
 * This file contains the application settings
 */
if (file_exists('../config.php')) {
    require_once '../config.php';
} else {
    //TODO: Create the config file
    echo 'ERROR: Missing application configuration file.';
    die();
}

/*
 * Is there a config_db file?
 * This file contains the database settings
 */
if (file_exists('../config_db.php')) {
    require_once '../config_db.php';
} else {
    //TODO: Create the config_db file
    echo 'ERROR: Missing database configuration file.';
    die();
}


/*
 * Start the session 
 */
$session_start = session_start();

/**
 * Set the page title
 */
$pageName = DEFAULT_PAGE;
if (array_key_exists('p', $_GET)) {
    $pageName = $_GET['p'];
}

/*
 * Is there a config file?
 */

/*
 * Call the page maker
 */
require_once 'Page.php';
?>