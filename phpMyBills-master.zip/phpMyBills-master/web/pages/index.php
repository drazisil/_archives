<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo APP_TITLE; ?></title>
        <link rel=icon href=img/favicon.png sizes="16x16" type="image/png">
        <link rel="stylesheet" href="page_widgets/toolbar.css">
    </head>
    <body>
        <?php
        require_once 'page_widgets/toolbar.php';
        ?>
    </body>
</html>