<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo APP_TITLE; ?> : Register</title>
        <link rel=icon href=img/favicon.png sizes="16x16" type="image/png">
        <link rel="stylesheet" href="page_widgets/toolbar.css">
    </head>
    <body>
        <?php
        require_once 'page_widgets/toolbar.php';
        ?>
        <form id="formRegister" name="formRegister">
            <label for="username">Username: <input id="username" name="username" type="text"></label><br>
            <label for="password">Password: <input id="password" name="password" type="password"></label><br>
            <label for="password2">Confirm: <input id="password2" name="password2" type="password"></label><br>
            <input name="register" type="submit" value="Register">
            <a href="?p=Login">Use an existing login</a>
        </form>
    </body>
</html>