# RegionAudit
This plugin allows you to run an audit on a WorldGuard region and quickly see when the owners were last on the server

## Installation

### Required Dependencies
* [WorldEdit](http://dev.bukkit.org/server-mods/worldedit/)
* [WorldGuard](http://dev.bukkit.org/server-mods/worldguard/)

## Commands
* /rgaudit <plotid> [<worldname>]- audit the lastPlayed date of the region's owners as a player
* /rgaudit <plotid> <worldname> - audit the lastPlayed date of the region's owners from the console

Please note that worldname is required if issued from console.

## Permissions


* regionaudit.audit - the ability to use /rgaudit

## Configuration
None yet

## Source
[![github](http://assets.jwebnet.net/img/github_small.png "github")](https://github.com/drazisil/regionaudit "github")
