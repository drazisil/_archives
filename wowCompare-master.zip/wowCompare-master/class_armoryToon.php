<?php
class armoryToon {

	public $name;
	public $class;
	public $level;
	public $guildName;
	public $race;
	public $lastModified;
	public $talents0;
	public $talents1;
	public $items;
	public $errCode = '';
	private $toonXML;

   function __construct($toonXML) {
       $this->toonXML = $toonXML;
   }


	public function fetchToon() {
		$toonXML = $this->toonXML;
		$this->name = $toonXML->characterInfo->character['name'];

		if ( $this->name <> '' ) {
			// There is a valid Toon here
			$this->class = $toonXML->characterInfo->character['class'];
			$this->level = $toonXML->characterInfo->character['level'];
			$this->guildName = $toonXML->characterInfo->character['guildName'];
			$this->race = $toonXML->characterInfo->character['race'];
			$this->lastModified = $toonXML->characterInfo->character['lastModified'];
			$this->errCode = $toonXML->characterInfo['errCode'];
			if ($this->errCode <> '') {
				//The armory returned an error
				return;
			}
			$this->talents0['name'] = $toonXML->characterInfo->characterTab->talentSpecs->talentSpec[0]['prim'];
			$this->talents1['name'] = $toonXML->characterInfo->characterTab->talentSpecs->talentSpec[1]['prim'];

			$this->items['count'] = count($toonXML->characterInfo->characterTab->items->item);

			for ($i = 0; $i <= 18; $i++) {
				$this->items['slot'.$i]['name'] = '';
			}

			if ( $this->items['count'] > 1 ) {
				foreach ($toonXML->characterInfo->characterTab->items->item as $item) {
					$this->items['slot'.$item['slot']]['name'] = $item['name'];
					$this->items['slot'.$item['slot']]['displayInfoId'] = $item['displayInfoId'];
					$this->items['slot'.$item['slot']]['durability'] = $item['durability'];
					$this->items['slot'.$item['slot']]['gem0Id'] = $item['gem0Id'];
					$this->items['slot'.$item['slot']]['gem1Id'] = $item['gem1Id'];
					$this->items['slot'.$item['slot']]['gem2Id'] = $item['gem2Id'];
					$this->items['slot'.$item['slot']]['icon'] = $item['icon'];
					$this->items['slot'.$item['slot']]['id'] = $item['id'];
					$this->items['slot'.$item['slot']]['level'] = $item['level'];
					$this->items['slot'.$item['slot']]['maxDurability'] = $item['maxDurability'];
					$this->items['slot'.$item['slot']]['permanentenchant'] = $item['permanentenchant'];
					$this->items['slot'.$item['slot']]['randomPropertiesId'] = $item['randomPropertiesId'];
					$this->items['slot'.$item['slot']]['rarity'] = $item['rarity'];
					$this->items['slot'.$item['slot']]['seed'] = $item['seed'];
					$this->items['slot'.$item['slot']]['slot'] = $item['slot'];
				}
			}

		} else {
			// No toon found
			$this->errCode = "invalidCharacter";
		}

	}

	public function dumpData() {

		echo 'Name: '.$this->name."<br>\n";
		echo 'Class: '.$this->class."<br>\n";
		echo 'Level: '.$this->level."<br>\n";
		echo 'Guild: '.$this->guildName."<br>\n";
		echo 'Race: '.$this->race."<br>\n";
		echo 'Last Update: '.$this->lastModified."<br>\n";
		echo 'Talent 1: '.$this->talents0['name']."<br>\n";
		echo 'Talent 2: '.$this->talents1['name']."<br>\n";
		for ($i = 0; $i <= 18; $i++) {
			echo 'Slot '.$i.': '.$this->items['slot'.$i]['name']."<br>\n";
		}
	}

}
?>