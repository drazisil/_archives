<?php
/*
*	When created, needs to check if the cached copy is older then the live copy
*
*	If it's older, pull the caches copy into $this->realms
*
*	If it's stale, or doesn't exist, fetch and cache it
*
*/
class realmList {

	public $XML;
	public $realms;
	public $count = -1;
	public $country;
	private $lastModified;

	function __construct($url, $country) {
		$this->country = $country;
		$this->fetch($url);
	}

	public function listRealms() {
		return $this->realms;
	}

	public function dumpXML() {
		echo "<pre>\n";
		print_r($this->XML);
		echo "</pre><br>\n";
	}

	public function dumpThis() {
		echo "<pre>\n";
		print_r($this);
		echo "</pre><br>\n";
	}

	private function fetch($url) {
		$folderData = 'data';
		$folderThis = getcwd();

		$folderData = $folderThis.'/'.$folderData;

		if (!is_dir($folderData)) {
			mkdir($folderData,0777,true);
		}

		$filename = 'realms_'.strtolower($this->country).'.txt';

		$filePath = $folderData.'/'.$filename;

		if (file_exists($filePath)) {
			// Get the last modified time of the cachc
			$lastModified_save = filemtime($filePath);
		} else {
			// no cache, post-date the time to trigger caching
			$lastModified_save = strtotime("1 January 2010 CST");
		}

		$this->XML = curl2XML($url);
		$this->lastModified = strtotime($this->XML->channel->lastBuildDate);

		$diff = dateDiff($this->lastModified, $lastModified_save);

		if ($diff['fullDays'] > 0 ) {
			// Cache is stale
			foreach ($this->XML->channel->item as $realm) {
				$this->count++;
				$t = explode("(", $realm->title);
				$this->realms[] = rtrim(addslashes($t[0]));
			}
			file_put_contents($filePath, implode(",", $this->realms));
		} else {
			// Cache is current, load it
			$this->realms = explode(",", file_get_contents($filePath));
			foreach ($this->realms as $realm) {
				$this->count++;
			}
		}
	}
}
?>