var obj;

function ProcessXML(url) {
  // native  object

  if (window.XMLHttpRequest) {
    // obtain new object
    obj = new XMLHttpRequest();
    // set the callback function
    obj.onreadystatechange = processChange;
    // we will do a GET with the url; "true" for asynch
    obj.open("GET", url, true);
    // null for GET with native object
    obj.send(null);
  // IE/Windows ActiveX object
  } else if (window.ActiveXObject) {
    obj = new ActiveXObject("Microsoft.XMLHTTP");
    if (obj) {
      obj.onreadystatechange = processChange;
      obj.open("GET", url, true);
      // don't send null for ActiveX
      obj.send();
    }
  } else {
    alert("Your browser does not support AJAX");
  }
}

function processChange() {
    // 4 means the response has been returned and ready to be processed
    if (obj.readyState == 4) {
        // 200 means "OK"
        if (obj.status == 200) {
         		document.getElementById('toonData').innerHTML = obj.responseText;
         		document.getElementById('toonData').innerHTML = document.getElementById('toonData').innerHTML;
        // anything else means a problem
        } else {
            alert("There was a problem in the returned data:\n");
        }
    } else {
		// Still waiting
    }
}

function fetchToon(response) {

	realm = document.getElementById('toonRealm').options[document.getElementById('toonRealm').selectedIndex].value;
	name = document.getElementById('toonName').value;
  // if response is not empty, we have received data back from the server
  if (response != '') {
    // the value of response is returned from checkName.php: 1 means in use
    if (response == '1') {
       alert("username is in use");
    }
    } else {
    //  if response is empty, we need to send the username to the server
       url  =  'server.php?r=' + realm + '&n=' + name;
       ProcessXML(url);
    }
	return false;
}