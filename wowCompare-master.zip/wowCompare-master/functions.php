<?php
function curl2XML( $url ) {

	$browser = "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.2) Gecko/20070319 Firefox/2.0.0.3";

	$ch = curl_init();
	curl_setopt ($ch, CURLOPT_URL, $url);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt ($ch, CURLOPT_USERAGENT, $browser);

	$url_string = curl_exec($ch);
	curl_close($ch);

	$xmlData = simplexml_load_string($url_string);

	return $xmlData;
}

function dateDiff($date1, $date2) {
	if ($date1 < $date2 ) {
		$dateDiff    = $date2 - $date1;
	} else {
		$dateDiff    = $date1 - $date2;
	}
	$diff['fullDays']    = floor($dateDiff/(60*60*24));
	$diff['fullHours']   = floor(($dateDiff-($diff['fullDays']*60*60*24))/(60*60));
	$diff['fullMinutes'] = floor(($dateDiff-($diff['fullDays']*60*60*24)-($diff['fullHours']*60*60))/60);
	return $diff;
}
?>