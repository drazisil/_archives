<?php

require('config.php');
require('functions.php');
require('class_armoryToon.php');
require('class_realmList.php');
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>wowCompare</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script type="text/javascript" src="functions.js"></script>
<style type="text/css">
	body {
		font-family: verdana, arial, sans-serif;
	}
</style>
</head>
<body>
<div>

<?php
$realmListURL_US = 'http://www.worldofwarcraft.com/realmstatus/index.xml';
$realmListURL_EU = 'http://www.wow-europe.com/realmstatus/index.xml';


$temp = new realmList($realmListURL_US, 'US');
$realmList['US'] = $temp->listRealms();
$temp = new realmList($realmListURL_EU, 'EU');
$realmList['EU'] = $temp->listRealms();

//http://www.wowarmory.com/character-sheet.xml?r=Kael'thas&cn=Mavang
$armoryCharacterURL['US'] = 'http://www.wowarmory.com/character-sheet.xml';
$armoryCharacterURL['EU'] = 'http://eu.wowarmory.com/character-sheet.xml';

echo "<form name=\"selectToon\" onsubmit=\"return fetchToon('');\">\n";
echo "<select id=\"toonRealm\" name=\"toonRealm\">\n";
echo "<option value=\"\">US</option>\n";
foreach ($realmList['US'] as $realm) {
	echo "<option value=\"".stripslashes($realm)."\">".stripslashes($realm)."</option>\n";
}
echo "</select><br>\n";

echo "<select id=\"toonRealm\" name=\"toonRealm\">\n";
echo "<option value=\"\">EU</option>\n";
foreach ($realmList['EU'] as $realm) {
	echo "<option value=\"".stripslashes($realm)."\">".stripslashes($realm)."</option>\n";
}
echo "</select><br>\n";
echo "Name: <input type=\"text\" id=\"toonName\" name=\"toonName\"><br>";
echo "<input type=\"submit\"><br>";
echo "</form>\n";

echo '<hr>';
?>
</div>
<div id="toonData">
</div>
<div id="footer">
All images &copy;2010 BLIZZARD ENTERTAINMENT, INC. ALL RIGHTS RESERVED.
</div>
</body>
</html>