<?php

require('config.php');
require('functions.php');
require('class_armoryToon.php');
require('class_realmList.php');

//http://www.wowarmory.com/character-sheet.xml?r=Kael'thas&cn=Mavang
$armoryCharacterURL['US'] = 'http://www.wowarmory.com/character-sheet.xml';
$armoryCharacterURL['EU'] = 'http://eu.wowarmory.com/character-sheet.xml';

if ( !$_GET['r'] ) {
	$armoryRealm = 'Kael\'thas';
} else {
	$armoryRealm = $_GET['r'];
}

if ( !$_GET['n'] ) {
	$armoryCharacterName = 'Torhment';
} else {
	$armoryCharacterName = $_GET['n'];
}

$xmlFile = $armoryCharacterURL['US'].'?r='.$armoryRealm.'&cn='.$armoryCharacterName;

echo '<a href="'.htmlentities($xmlFile)."\"><img src=\"Icon-armory-22x22.png\"></a><br><br>\n";

$xmlData = curl2XML($xmlFile);

$toon = new armoryToon($xmlData);

$toon->fetchToon();
if ($toon->errCode <> '') {
	echo $toon->errCode;
} else {
	$toon->dumpData();
}

echo '<hr>';
?>