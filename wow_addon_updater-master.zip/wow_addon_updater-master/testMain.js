const webdriverio = require('webdriverio')
var options = {
  host: 'localhost', // Use localhost as chrome driver server
  port: 9515,        // "9515" is the port opened by chrome driver.
  desiredCapabilities: {
    browserName: 'chrome',
    takesScreenshot: true,
    chromeOptions: {
      binary: process.env.ELECTRON_BINARY, // Path to your Electron binary.
      args: [
        'app=./main.js',
        '--user-data-dir=./profiles'
      ]
    }
  }
}

var client = webdriverio.remote(options)

client
  .init()
  .getTitle().then(function (title) {
    console.log('Title was: ' + title)
  })
  .end()
